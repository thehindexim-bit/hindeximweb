import Link from "next/link";
import { ArrowUpRight, Phone } from "lucide-react";
import Logo from "@/components/Logo";
import { SERVICES, SITE } from "@/lib/site";

export default function Footer({ phoneDisplay, phoneHref }: { phoneDisplay: string; phoneHref: string }) {
  return (
    <footer className="relative border-t border-line bg-abyss">
      <div id="contact" className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:px-10 lg:py-24">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <p className="stencil text-[11px] text-gold">One desk · one call · every trade lane</p>
            <h2 className="font-display mt-4 text-[clamp(2rem,4.5vw,3.6rem)] font-black leading-[1.02] tracking-tight">
              TALK TO THE
              <br />
              <span className="text-gold">TRADE DESK.</span>
            </h2>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-mist">
              Freight rates, buyer mandates, supplier enquiries or merchant-export tie-ups —
              every conversation at Hind Exim starts with the same number.
            </p>
            <a
              href={phoneHref}
              className="group mt-8 inline-flex items-center gap-4 rounded-2xl border border-gold/40 bg-gold/10 px-6 py-4 transition-colors hover:bg-gold/20"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gold text-ink">
                <Phone size={18} />
              </span>
              <span>
                <span className="stencil block text-[9px] text-mist">Call us · 24×7</span>
                <span className="font-display text-xl font-bold text-bone group-hover:text-gold sm:text-2xl">
                  {phoneDisplay}
                </span>
              </span>
              <ArrowUpRight size={18} className="text-gold transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
            </a>
          </div>

          <div>
            <p className="stencil text-[10px] text-dim">Services</p>
            <ul className="mt-5 space-y-3">
              <li>
                <Link href="/freight-forwarding" className="group flex items-center gap-2 text-[14px] text-mist transition-colors hover:text-gold">
                  <span className="text-gold/60">01</span> Freight Forwarding
                  <ArrowUpRight size={12} className="opacity-0 transition-opacity group-hover:opacity-100" />
                </Link>
              </li>
              <li>
                <Link href="/buyers" className="group flex items-center gap-2 text-[14px] text-mist transition-colors hover:text-gold">
                  <span className="text-gold/60">02</span> Buyer Sourcing
                  <ArrowUpRight size={12} className="opacity-0 transition-opacity group-hover:opacity-100" />
                </Link>
              </li>
              <li>
                <Link href="/sellers" className="group flex items-center gap-2 text-[14px] text-mist transition-colors hover:text-gold">
                  <span className="text-gold/60">03</span> Seller Sourcing
                  <ArrowUpRight size={12} className="opacity-0 transition-opacity group-hover:opacity-100" />
                </Link>
              </li>
              <li>
                <Link href="/#services" className="group flex items-center gap-2 text-[14px] text-mist transition-colors hover:text-gold">
                  <span className="text-gold/60">04</span> Merchant Exports
                  <ArrowUpRight size={12} className="opacity-0 transition-opacity group-hover:opacity-100" />
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <p className="stencil text-[10px] text-dim">Platform</p>
            <ul className="mt-5 space-y-3 text-[14px]">
              <li><Link className="text-mist transition-colors hover:text-gold" href="/buyers">Buyer requirements</Link></li>
              <li><Link className="text-mist transition-colors hover:text-gold" href="/sellers">Seller listings</Link></li>
              <li><Link className="text-mist transition-colors hover:text-gold" href="/dashboard">Post a requirement</Link></li>
              <li><Link className="text-mist transition-colors hover:text-gold" href="/login">Log in</Link></li>
              <li><Link className="text-mist transition-colors hover:text-gold" href="/signup">Create account</Link></li>
            </ul>
            <p className="stencil mt-8 text-[10px] text-dim">Base</p>
            <p className="mt-3 text-[14px] text-mist">{SITE.base}</p>
          </div>
        </div>
      </div>

      <div className="border-t border-line">
        <div className="mx-auto flex max-w-[1400px] flex-col items-center justify-between gap-4 px-4 py-6 sm:flex-row sm:px-6 lg:px-10">
          <Logo />
          <p className="stencil text-center text-[9px] text-dim">
            © {new Date().getFullYear()} {SITE.name} · Export Trade House · All rights reserved
          </p>
        </div>
      </div>
      <div className="tricolor h-[3px] w-full" aria-hidden />
    </footer>
  );
}

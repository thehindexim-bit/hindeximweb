"use client";

import { useState } from "react";
import { ArrowRight, Loader2, ShieldCheck } from "lucide-react";
import { SITE } from "@/lib/site";

const SECTORS = [
  "Agro Commodities & Grains",
  "Spices & Condiments",
  "Textiles, Yarns & Made-ups",
  "Engineering & Metal Scrap",
  "Pharmaceuticals & APIs",
  "Chemicals & Minerals",
  "General",
];

export default function SupplierRequestForm({
  onSubmitted,
}: {
  onSubmitted?: () => void;
}) {
  const [form, setForm] = useState({
    companyName: "",
    contactName: "",
    phone: "",
    sector: "General",
    commodity: "",
    originCountry: "India",
    description: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/supplier-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data?.error ?? "Could not submit request. Try again.");
        return;
      }
      setForm({
        companyName: "",
        contactName: "",
        phone: "",
        sector: "General",
        commodity: "",
        originCountry: "India",
        description: "",
      });
      setDone(true);
      onSubmitted?.();
      setTimeout(() => setDone(false), 5000);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-line bg-panel/70 p-6">
      <div className="flex items-center gap-2 mb-4">
        <ShieldCheck size={16} className="text-leaf" />
        <p className="stencil text-[10px] text-leaf font-bold">Admin Approval Required</p>
      </div>

      <div className="space-y-3.5">
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Company Name *</label>
            <input
              required
              className="field"
              placeholder="e.g. Global Foods Exports Pvt Ltd"
              value={form.companyName}
              onChange={set("companyName")}
            />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Contact Person *</label>
            <input
              required
              className="field"
              placeholder="e.g. Mr. Arjun Sharma"
              value={form.contactName}
              onChange={set("contactName")}
            />
          </div>
        </div>
        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Phone / WhatsApp *</label>
          <input
            required
            className="field"
            placeholder="98765 43210"
            value={form.phone}
            onChange={set("phone")}
          />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Export Sector *</label>
            <select
              required
              className="field"
              value={form.sector}
              onChange={set("sector")}
            >
              <option value="">Select sector</option>
              {SECTORS.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Commodity / Product *</label>
            <input
              required
              className="field"
              placeholder="e.g. Basmati Rice 1121, Turmeric Fingers"
              value={form.commodity}
              onChange={set("commodity")}
            />
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Origin Country *</label>
            <input
              required
              className="field"
              placeholder="India"
              value={form.originCountry}
              onChange={set("originCountry")}
            />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Target Monthly Volume</label>
            <input
              className="field"
              placeholder="e.g. 100 MT / month"
              value={form.description}
              onChange={set("description")}
            />
          </div>
        </div>
        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Additional Notes</label>
            <textarea
              className="field min-h-[80px] resize-y"
              placeholder="Certifications, factory capacity, packaging details..."
              value={form.description}
              onChange={set("description")}
            />
        </div>
      </div>

      {error && <p className="mt-4 rounded-lg border border-red-500/40 bg-red-500/10 px-4 py-2.5 text-[13px] text-red-300">{error}</p>}
      {done && (
        <p className="mt-4 flex items-center gap-2 rounded-lg border border-leaf/40 bg-leaf/10 px-4 py-2.5 text-[13px] text-leaf">
          <ShieldCheck size={15} />
          Supplier request submitted for admin review.
        </p>
      )}

      <button
        type="submit"
        disabled={busy}
        className="clip-notch mt-6 flex w-full items-center justify-center gap-2 bg-leaf px-8 py-3.5 text-[14px] font-bold text-ink transition-colors hover:brightness-110 disabled:opacity-60"
      >
        {busy ? <Loader2 size={15} className="animate-spin" /> : <ArrowRight size={15} />}
        Submit Supplier Request for Review
      </button>

      <p className="stencil mt-3 text-center text-[8px] text-dim">
        Your request will be reviewed by the Hind Exim admin desk before going live.
      </p>
    </form>
  );
}

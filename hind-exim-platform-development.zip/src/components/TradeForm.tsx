"use client";

import { useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  Loader2,
  MessageCircle,
  Send,
  X,
} from "lucide-react";
import { SITE } from "@/lib/site";

const CATEGORIES = [
  "Agriculture & Food",
  "Spices",
  "Textiles & Apparel",
  "Pharmaceuticals",
  "Metals & Scrap",
  "Chemicals",
  "Handicrafts",
  "Engineering Goods",
  "Consumer Goods",
  "General",
];

const UNITS = ["MT", "KG", "CBM", "20FT FCL", "40FT FCL", "PCS", "CARTONS"];

export type TradeMode = "buyer" | "seller";

export default function TradeForm({
  initialMode,
  onClose,
}: {
  initialMode: TradeMode;
  onClose: () => void;
}) {
  const [mode, setMode] = useState<TradeMode>(initialMode);
  const [form, setForm] = useState({
    title: "",
    category: "General",
    hsCode: "",
    quantity: "",
    unit: "MT",
    originCountry: "",
    destinationCountry: "",
    priceRange: "",
    description: "",
    company: "",
    contactName: "",
    phone: "",
  });
  const [busy, setBusy] = useState(false);

  const set =
    (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  function buildMessage(): string {
    const lines = [
      `*HIND EXIM — Trade Enquiry*`,
      ``,
      `*I want to:* ${mode === "buyer" ? "BUY / SOURCE" : "SELL / SUPPLY"}`,
      `*Product / Commodity:* ${form.title || "—"}`,
      `*Category:* ${form.category}`,
      form.hsCode ? `*HS Code:* ${form.hsCode}` : null,
      form.quantity ? `*Quantity:* ${form.quantity} ${form.unit}` : null,
      mode === "buyer"
        ? form.destinationCountry
          ? `*Destination Country:* ${form.destinationCountry}`
          : null
        : form.originCountry
        ? `*Origin Country:* ${form.originCountry}`
        : null,
      form.priceRange ? `*Price / Terms:* ${form.priceRange}` : null,
      form.description ? `*Details:* ${form.description}` : null,
      ``,
      `*Contact Person:* ${form.contactName || "—"}`,
      form.company ? `*Company:* ${form.company}` : null,
      form.phone ? `*Phone / WhatsApp:* ${form.phone}` : null,
      ``,
      `Sent from the Hind Exim website trade desk.`,
    ].filter(Boolean) as string[];
    return lines.join("\n");
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.title.trim()) return;
    setBusy(true);
    const message = buildMessage();
    const url = `${SITE.whatsapp}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");
    // brief delay so the user sees the action before WhatsApp opens
    setTimeout(() => setBusy(false), 600);
  }

  const isBuyer = mode === "buyer";

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 bg-ink/80 backdrop-blur-sm"
      />
      <div className="relative max-h-[92vh] w-full max-w-[560px] overflow-y-auto rounded-2xl border border-line bg-panel/95 p-6 shadow-[0_40px_120px_-30px_rgba(0,0,0,0.9)] backdrop-blur-xl sm:p-8">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full border border-line p-2 text-mist transition-colors hover:border-gold hover:text-gold"
          aria-label="Close form"
        >
          <X size={16} />
        </button>

        <p className="stencil text-[10px] text-gold">Trade Desk Enquiry</p>
        <h2 className="font-display mt-2 text-2xl font-black tracking-tight text-bone sm:text-3xl">
          {isBuyer ? "I want to BUY" : "I want to SELL"}
        </h2>
        <p className="mt-1 text-[13px] text-mist">
          Fill in the details — on submit, WhatsApp opens with everything pre-filled to{" "}
          <span className="font-semibold text-gold">{SITE.phoneDisplay}</span>.
        </p>

        {/* mode toggle */}
        <div className="mt-5 grid grid-cols-2 gap-2 rounded-full border border-line bg-abyss/60 p-1.5">
          <button
            type="button"
            onClick={() => setMode("buyer")}
            className={`stencil flex items-center justify-center gap-1.5 rounded-full py-2.5 text-[10px] transition-all ${
              isBuyer ? "bg-gold font-bold text-ink" : "text-mist hover:text-bone"
            }`}
          >
            <ArrowDownRight size={12} /> I want to buy
          </button>
          <button
            type="button"
            onClick={() => setMode("seller")}
            className={`stencil flex items-center justify-center gap-1.5 rounded-full py-2.5 text-[10px] transition-all ${
              !isBuyer ? "bg-leaf font-bold text-ink" : "text-mist hover:text-bone"
            }`}
          >
            <ArrowUpRight size={12} /> I want to sell
          </button>
        </div>

        <form onSubmit={submit} className="mt-5 space-y-3.5">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">
              Product / commodity *
            </label>
            <input
              required
              className="field"
              placeholder={
                isBuyer ? "e.g. Basmati Rice 1121 Steam" : "e.g. Turmeric Fingers 5% curcumin"
              }
              value={form.title}
              onChange={set("title")}
            />
          </div>

          <div className="grid gap-3.5 sm:grid-cols-2">
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">Category</label>
              <select className="field" value={form.category} onChange={set("category")}>
                {CATEGORIES.map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">HS code</label>
              <input
                className="field"
                placeholder="e.g. 1006.30"
                value={form.hsCode}
                onChange={set("hsCode")}
              />
            </div>
          </div>

          <div className="grid gap-3.5 sm:grid-cols-2">
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">Quantity</label>
              <input
                className="field"
                placeholder="e.g. 500"
                value={form.quantity}
                onChange={set("quantity")}
              />
            </div>
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">Unit</label>
              <select className="field" value={form.unit} onChange={set("unit")}>
                {UNITS.map((u) => (
                  <option key={u}>{u}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid gap-3.5 sm:grid-cols-2">
            {isBuyer ? (
              <div>
                <label className="stencil mb-1.5 block text-[9px] text-dim">
                  Destination country
                </label>
                <input
                  className="field"
                  placeholder="e.g. UAE"
                  value={form.destinationCountry}
                  onChange={set("destinationCountry")}
                />
              </div>
            ) : (
              <div>
                <label className="stencil mb-1.5 block text-[9px] text-dim">Origin country</label>
                <input
                  className="field"
                  placeholder="e.g. India"
                  value={form.originCountry}
                  onChange={set("originCountry")}
                />
              </div>
            )}
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">
                Target price / terms
              </label>
              <input
                className="field"
                placeholder="e.g. FOB $850/MT"
                value={form.priceRange}
                onChange={set("priceRange")}
              />
            </div>
          </div>

          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Details</label>
            <textarea
              className="field min-h-[72px] resize-y"
              placeholder="Specs, packaging, certifications, timeline…"
              value={form.description}
              onChange={set("description")}
            />
          </div>

          <div className="grid gap-3.5 sm:grid-cols-2">
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">Contact person *</label>
              <input
                required
                className="field"
                placeholder="e.g. Mr. Kapoor"
                value={form.contactName}
                onChange={set("contactName")}
              />
            </div>
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">Company</label>
              <input
                className="field"
                placeholder="e.g. Al Noor Trading LLC"
                value={form.company}
                onChange={set("company")}
              />
            </div>
          </div>

          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Phone / WhatsApp *</label>
            <input
              required
              className="field"
              placeholder="98765 43210"
              value={form.phone}
              onChange={set("phone")}
            />
          </div>

          <button
            type="submit"
            disabled={busy || !form.title.trim() || !form.contactName.trim()}
            className={`clip-notch mt-2 flex w-full items-center justify-center gap-2 px-6 py-4 text-[14px] font-bold text-ink transition-colors disabled:opacity-60 ${
              isBuyer ? "bg-gold hover:bg-saffron" : "bg-leaf hover:brightness-110"
            }`}
          >
            {busy ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <MessageCircle size={16} />
            )}
            Submit via WhatsApp
          </button>
          <p className="stencil text-center text-[8px] text-dim">
            Opens WhatsApp chat to {SITE.phoneDisplay} with your enquiry pre-filled
          </p>
        </form>
      </div>
    </div>
  );
}

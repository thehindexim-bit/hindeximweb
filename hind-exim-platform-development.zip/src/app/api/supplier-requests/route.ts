import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { eq, desc } from "drizzle-orm";
import { supplierRequests } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.email) {
    return NextResponse.json({ error: "You must be signed in to submit a supplier request." }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const companyName = String(body?.companyName ?? "").trim();
  const contactName = String(body?.contactName ?? "").trim();
  const email = String(body?.email ?? session.user.email ?? "").trim().toLowerCase() || null;
  const phone = String(body?.phone ?? "").trim() || "pending";
  const sector = String(body?.sector ?? "").trim();
  const commodity = String(body?.commodity ?? "").trim();
  const originCountry = String(body?.originCountry ?? "").trim();
  const description = String(body?.description ?? "").trim() || null;

  if (!companyName || !contactName || !sector || !commodity || !originCountry) {
    return NextResponse.json({ error: "All required fields must be filled." }, { status: 400 });
  }

  // Prevent duplicate pending requests from same phone
  const [existing] = await db
    .select()
    .from(supplierRequests)
    .where(eq(supplierRequests.phone, phone!))
    .orderBy(desc(supplierRequests.createdAt))
    .limit(1);

  if (existing && existing.status === "pending") {
    return NextResponse.json({ error: "You already have a pending supplier request. Please wait for admin review." }, { status: 409 });
  }

  const [created] = await db
    .insert(supplierRequests)
    .values({
      companyName,
      contactName,
      email,
      phone,
      sector,
      commodity,
      originCountry,
      description,
      status: "pending",
    })
    .returning();

  return NextResponse.json({ ok: true, item: { id: created.id, status: created.status } });
}

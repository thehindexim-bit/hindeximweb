import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import type { NextResponse } from "next/server";

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  role: string;
};

const COOKIE = "hx_session";
const UI_COOKIE = "hx_ui";
const MAX_AGE = 60 * 60 * 24 * 30;

function secret() {
  return process.env.AUTH_SECRET ?? process.env.NEXTAUTH_SECRET ?? "hind-exim-dev-secret-key-change-in-production";
}

function sign(payload: string) {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function encodeSession(user: SessionUser) {
  const payload = Buffer.from(JSON.stringify({ ...user, exp: Date.now() + MAX_AGE * 1000 })).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function decodeSession(token: string | undefined | null): SessionUser | null {
  if (!token || !token.includes(".")) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as SessionUser & { exp?: number };
    if (data.exp && Date.now() > data.exp) return null;
    if (!data.id || !data.email) return null;
    return { id: String(data.id), email: data.email, name: data.name, role: data.role };
  } catch {
    return null;
  }
}

export function attachSessionCookies(res: NextResponse, user: SessionUser) {
  res.cookies.set(COOKIE, encodeSession(user), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: MAX_AGE,
    secure: false,
  });
  res.cookies.set(UI_COOKIE, encodeURIComponent(JSON.stringify(user)), {
    httpOnly: false,
    sameSite: "lax",
    path: "/",
    maxAge: MAX_AGE,
    secure: false,
  });
  return res;
}

export function clearSessionCookies(res: NextResponse) {
  res.cookies.set(COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  res.cookies.set(UI_COOKIE, "", { httpOnly: false, path: "/", maxAge: 0 });
  return res;
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  return decodeSession(jar.get(COOKIE)?.value);
}

export const SESSION_COOKIE = COOKIE;
export const UI_SESSION_COOKIE = UI_COOKIE;

/** Build an absolute URL on the public host (never 0.0.0.0). */
export function publicUrl(req: Request, path: string) {
  const p = path.startsWith("/") ? path : `/${path}`;
  const referer = req.headers.get("referer");
  if (referer && !referer.includes("0.0.0.0")) {
    try {
      return new URL(p, referer);
    } catch {
      /* fall through */
    }
  }
  const forwardedHost = req.headers.get("x-forwarded-host");
  let host = forwardedHost || req.headers.get("host") || "localhost:3000";
  if (host.startsWith("0.0.0.0")) host = host.replace("0.0.0.0", "127.0.0.1");
  const proto =
    req.headers.get("x-forwarded-proto") ||
    (host.includes("localhost") || host.startsWith("127.") ? "http" : "https");
  return new URL(p, `${proto}://${host}`);
}

/** Normalize any Indian / international input to E.164 (+91…). */
export function normalizePhone(phone: string): string {
  const digits = String(phone ?? "").replace(/\D/g, "");
  if (!digits) return "";
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 11 && digits.startsWith("0")) return `+91${digits.slice(1)}`;
  if (digits.length === 12 && digits.startsWith("91")) return `+${digits}`;
  if (digits.startsWith("91") && digits.length >= 12) return `+${digits}`;
  return `+${digits}`;
}

export function isValidPhone(phone: string): boolean {
  const n = normalizePhone(phone);
  return /^\+\d{10,15}$/.test(n);
}

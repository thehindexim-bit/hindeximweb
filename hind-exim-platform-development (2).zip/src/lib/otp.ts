import { randomInt } from "node:crypto";
import { and, desc, eq, gt, isNull, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { phoneAuthTickets, phoneOtps } from "@/db/schema";
import { normalizePhone } from "@/lib/phone";

const OTP_TTL_MINUTES = 10;
const TICKET_TTL_MINUTES = 15;
const MAX_ATTEMPTS = 8;
const MAX_OTPS_PER_WINDOW = 8;
const RATE_WINDOW_MINUTES = 15;

function hashCode(code: string): string {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < code.length; i++) {
    h1 = (h1 ^ code.charCodeAt(i)) * 0x01000193;
    h2 = (h2 + code.charCodeAt(i) * (i + 7)) | 0;
  }
  return `${(h1 >>> 0).toString(36)}${(h2 >>> 0).toString(36)}`;
}

export function generateOtp(): string {
  return String(randomInt(0, 1000000)).padStart(6, "0");
}

export async function requestOtp(phone: string): Promise<{ code: string } | { error: string }> {
  const normalized = normalizePhone(phone);
  if (!normalized) return { error: "Enter a valid phone number." };
  const now = new Date();

  const recent = await db
    .select({ id: phoneOtps.id })
    .from(phoneOtps)
    .where(
      sql`${phoneOtps.phone} = ${normalized} AND ${phoneOtps.createdAt} > now() - interval '${sql.raw(String(RATE_WINDOW_MINUTES))} minutes'`
    )
    .limit(MAX_OTPS_PER_WINDOW);
  if (recent.length >= MAX_OTPS_PER_WINDOW) {
    return { error: "Too many codes requested. Please wait a few minutes and try again." };
  }

  await db
    .update(phoneOtps)
    .set({ consumedAt: now })
    .where(and(eq(phoneOtps.phone, normalized), isNull(phoneOtps.consumedAt)));

  const code = generateOtp();
  await db.insert(phoneOtps).values({
    phone: normalized,
    codeHash: hashCode(code),
    expiresAt: new Date(now.getTime() + OTP_TTL_MINUTES * 60_000),
    attempts: 0,
  });

  return { code };
}

export async function verifyOtp(
  phone: string,
  code: string
): Promise<{ ok: true } | { ok: false; error: string }> {
  const normalized = normalizePhone(phone);
  const [row] = await db
    .select()
    .from(phoneOtps)
    .where(and(eq(phoneOtps.phone, normalized), isNull(phoneOtps.consumedAt)))
    .orderBy(desc(phoneOtps.createdAt))
    .limit(1);

  if (!row) return { ok: false, error: "No active code. Please request a new one." };
  if (row.attempts >= MAX_ATTEMPTS) return { ok: false, error: "Too many wrong attempts. Request a new code." };
  if (row.expiresAt.getTime() < Date.now()) return { ok: false, error: "Code expired. Please request a new one." };
  if (hashCode(code.trim()) !== row.codeHash) {
    await db.update(phoneOtps).set({ attempts: row.attempts + 1 }).where(eq(phoneOtps.id, row.id));
    const left = MAX_ATTEMPTS - (row.attempts + 1);
    return {
      ok: false,
      error:
        left > 0
          ? `Incorrect code. ${left} attempt${left === 1 ? "" : "s"} left.`
          : "Too many wrong attempts. Request a new code.",
    };
  }

  await db.update(phoneOtps).set({ consumedAt: new Date() }).where(eq(phoneOtps.id, row.id));
  return { ok: true };
}

export async function createTicket(phone: string, purpose: "login" | "signup" = "login"): Promise<string> {
  const normalized = normalizePhone(phone);
  const token = `${randomInt(0, 1_000_000_000).toString(36)}${Date.now().toString(36)}${Math.random()
    .toString(36)
    .slice(2, 10)}`;
  await db.insert(phoneAuthTickets).values({
    token,
    phone: normalized,
    purpose,
    expiresAt: new Date(Date.now() + TICKET_TTL_MINUTES * 60_000),
  });
  return token;
}

export async function consumeTicket(token: string, phone: string): Promise<boolean> {
  if (!token || !phone) return false;
  const normalized = normalizePhone(phone);
  const [row] = await db
    .select()
    .from(phoneAuthTickets)
    .where(
      and(
        eq(phoneAuthTickets.token, token),
        eq(phoneAuthTickets.phone, normalized),
        isNull(phoneAuthTickets.usedAt),
        gt(phoneAuthTickets.expiresAt, new Date())
      )
    )
    .limit(1);
  if (!row) return false;
  await db.update(phoneAuthTickets).set({ usedAt: new Date() }).where(eq(phoneAuthTickets.id, row.id));
  return true;
}

export const SITE = {
  name: "HIND EXIM",
  legal: "Hind Exim Trade Services",
  tagline: "Export · Import · Simplified",
  phoneDisplay: "+91 91803 98801",
  phoneHref: "tel:+919180398801",
  whatsapp: "https://wa.me/919180398801",
  base: "Jaipur · Rajasthan · India",
};

export type ServiceSlug =
  | "freight-forwarding"
  | "buyer-sourcing"
  | "seller-sourcing"
  | "merchant-exports";

export const SERVICES: {
  slug: ServiceSlug;
  index: string;
  title: string;
  tagline: string;
  description: string;
  points: string[];
}[] = [
  {
    slug: "freight-forwarding",
    index: "01",
    title: "Freight Forwarding",
    tagline: "Sea · Air · Road — port to port, door to door.",
    description:
      "FCL & LCL ocean freight, air cargo and multimodal lanes with customs documentation, insurance and live tracking handled end-to-end by one desk.",
    points: ["FCL / LCL ocean cargo", "Air freight & express", "Customs & CHA documentation", "Cargo insurance & tracking"],
  },
  {
    slug: "buyer-sourcing",
    index: "02",
    title: "Buyer Sourcing",
    tagline: "Verified international buyers for your products.",
    description:
      "We scout, qualify and connect you with serious import houses across the Gulf, EU, Africa and the Americas — with LOIs, trade terms and payment security aligned before you ship.",
    points: ["40+ importing markets", "KYC-verified buy mandates", "LOI / ICPO handling", "Payment term advisory"],
  },
  {
    slug: "seller-sourcing",
    index: "03",
    title: "Seller Sourcing",
    tagline: "Factory-direct Indian suppliers, on mandate.",
    description:
      "From agro commodities to engineered goods, we locate, audit and negotiate with Indian manufacturers and farm-gate aggregators so you buy at source, not at markup.",
    points: ["Audited supplier network", "QC & pre-shipment inspection", "Sample & trial orders", "Contract negotiation"],
  },
  {
    slug: "merchant-exports",
    index: "04",
    title: "Merchant Exports",
    tagline: "We buy, we ship, we remit — under our export house.",
    description:
      "Hind Exim acts as your merchant exporter of record: procurement, export documentation, logistics and forex remittance executed on your behalf under one roof.",
    points: ["Export house operations", "DGFT / RoDTEP paperwork", "e-BRC & forex handling", "End-to-end execution"],
  },
];

export const TICKER_ITEMS = [
  "FREIGHT FORWARDING",
  "BUYER SOURCING",
  "SELLER SOURCING",
  "MERCHANT EXPORTS",
  "HS 1006 — BASMATI RICE",
  "HS 0910 — SPICES",
  "HS 5208 — COTTON TEXTILES",
  "HS 3004 — PHARMA",
  "HS 7404 — COPPER SCRAP",
  "Nhava Sheva → Jebel Ali",
  "Mundra → Rotterdam",
  "Chennai → Mombasa",
];

export type ClientRequirement = {
  id: number;
  kind: "buyer" | "seller";
  title: string;
  category: string;
  hsCode: string | null;
  quantity: string | null;
  unit: string | null;
  originCountry: string | null;
  destinationCountry: string | null;
  priceRange: string | null;
  description: string | null;
  company: string | null;
  contactName: string | null;
  postedByName: string | null;
  createdAt: string; // ISO
};

export type ClientUser = {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  role: string;
  provider: string;
  createdAt: string;
  lastLoginAt: string | null;
};

export type ClientLoginEvent = {
  id: number;
  phone?: string;
  email?: string;
  provider: string;
  createdAt: string;
};

export function timeAgo(iso: string | Date): string {
  const then = typeof iso === "string" ? new Date(iso) : iso;
  const s = Math.max(1, Math.floor((Date.now() - then.getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;
  return then.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

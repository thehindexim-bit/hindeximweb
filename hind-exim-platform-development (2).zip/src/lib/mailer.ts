import net from "node:net";
import tls from "node:tls";

/**
 * Dependency-free minimal SMTP client (TLS 465 / STARTTLS 587, AUTH LOGIN).
 * Avoids peer-dependency conflicts with next-auth's optional nodemailer peer.
 */

export type SmtpConfig = {
  host: string;
  port: number;
  secure: boolean;
  user: string;
  pass: string;
  from: string;
  fromName: string;
};

export function getSmtpConfig(): SmtpConfig | null {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  // Gmail app passwords are often pasted with spaces — strip all whitespace.
  const pass = process.env.SMTP_PASS?.replace(/\s+/g, "");
  if (!host || !user || !pass) return null;
  const port = Number(process.env.SMTP_PORT ?? 465);
  return {
    host,
    port,
    secure: port === 465,
    user,
    pass,
    from: process.env.SMTP_FROM ?? user,
    fromName: process.env.SMTP_FROM_NAME ?? "Hind Exim",
  };
}

class SmtpSession {
  private waiters: ((line: string) => void)[] = [];
  private buffer = "";
  private sock!: net.Socket;

  private onData = (chunk: string) => {
    this.buffer += chunk;
    let idx: number;
    while ((idx = this.buffer.indexOf("\r\n")) !== -1) {
      const line = this.buffer.slice(0, idx);
      this.buffer = this.buffer.slice(idx + 2);
      // final line of a reply is "NNN <text>"
      if (/^\d{3}(\s|$)/.test(line)) {
        const w = this.waiters.shift();
        w?.(line);
      }
    }
  };

  constructor(sock: net.Socket) {
    this.attach(sock);
  }

  private attach(sock: net.Socket) {
    this.sock = sock;
    sock.setEncoding("utf8");
    sock.on("data", this.onData);
    sock.on("error", (err) => {
      const w = this.waiters.shift();
      if (w) w(`421 ${err.message}`);
    });
  }

  upgrade(tlsSock: tls.TLSSocket) {
    this.sock.off("data", this.onData);
    this.attach(tlsSock);
  }

  expect(timeoutMs = 25000): Promise<string> {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("SMTP response timeout")), timeoutMs);
      this.waiters.push((line) => {
        clearTimeout(timer);
        resolve(line);
      });
    });
  }

  async cmd(command: string): Promise<string> {
    const pending = this.expect();
    this.sock.write(`${command}\r\n`);
    return pending;
  }

  async writeRaw(payload: string): Promise<string> {
    const pending = this.expect(40000);
    this.sock.write(payload);
    return pending;
  }

  close() {
    try {
      this.sock.end();
    } catch {
      /* ignore */
    }
  }
}

function connectSocket(cfg: SmtpConfig): Promise<net.Socket> {
  return new Promise((resolve, reject) => {
    const done = (sock: net.Socket) => {
      sock.pause();
      resolve(sock);
    };
    const fail = (err: Error) => reject(err);

    if (cfg.secure) {
      const sock = tls.connect({ host: cfg.host, port: cfg.port, servername: cfg.host });
      sock.once("secureConnect", () => done(sock));
      sock.once("error", fail);
    } else {
      const sock = net.connect({ host: cfg.host, port: cfg.port });
      sock.once("connect", () => done(sock));
      sock.once("error", fail);
    }
    setTimeout(() => fail(new Error("SMTP connection timeout")), 25000).unref?.();
  });
}

function dotStuff(body: string): string {
  return body
    .split("\r\n")
    .map((line) => (line.startsWith(".") ? `.${line}` : line))
    .join("\r\n");
}

export type MailInput = {
  to: string;
  subject: string;
  html: string;
  text: string;
};

export async function sendMail(cfg: SmtpConfig, mail: MailInput): Promise<void> {
  const sock = await connectSocket(cfg);
  const session = new SmtpSession(sock);
  sock.resume();

  const greeting = await session.expect();
  if (!greeting.startsWith("220")) throw new Error(`SMTP greeting rejected: ${greeting}`);

  const ehloName = process.env.SMTP_EHLO ?? "mail.hindexim.com";
  let ehlo = await session.cmd(`EHLO ${ehloName}`);
  if (!ehlo.startsWith("250")) throw new Error(`EHLO rejected: ${ehlo}`);

  if (!cfg.secure) {
    const starttls = await session.cmd("STARTTLS");
    if (!starttls.startsWith("220")) throw new Error(`STARTTLS rejected: ${starttls}`);
    const tlsSock = tls.connect({ socket: sock, servername: cfg.host });
    await new Promise<void>((resolve, reject) => {
      tlsSock.once("secureConnect", () => resolve());
      tlsSock.once("error", reject);
    });
    session.upgrade(tlsSock);
    ehlo = await session.cmd(`EHLO ${ehloName}`);
    if (!ehlo.startsWith("250")) throw new Error(`EHLO after STARTTLS rejected: ${ehlo}`);
  }

  if (cfg.user && cfg.pass) {
    const auth = await session.cmd("AUTH LOGIN");
    if (!auth.startsWith("334")) throw new Error(`AUTH LOGIN rejected: ${auth}`);
    const userRes = await session.cmd(Buffer.from(cfg.user).toString("base64"));
    if (!userRes.startsWith("334")) throw new Error(`AUTH user rejected: ${userRes}`);
    const passRes = await session.cmd(Buffer.from(cfg.pass).toString("base64"));
    if (!passRes.startsWith("235")) throw new Error(`AUTH password rejected: ${passRes}`);
  }

  const from = await session.cmd(`MAIL FROM:<${cfg.from}>`);
  if (!from.startsWith("250")) throw new Error(`MAIL FROM rejected: ${from}`);

  const rcpt = await session.cmd(`RCPT TO:<${mail.to}>`);
  if (!rcpt.startsWith("250")) throw new Error(`RCPT TO rejected: ${rcpt}`);

  const data = await session.cmd("DATA");
  if (!data.startsWith("354")) throw new Error(`DATA rejected: ${data}`);

  const messageId = `<${Date.now()}.${Math.random().toString(36).slice(2)}@hindexim.com>`;
  const headers = [
    `From: "${cfg.fromName}" <${cfg.from}>`,
    `To: <${mail.to}>`,
    `Subject: ${mail.subject}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: ${messageId}`,
    "MIME-Version: 1.0",
    'Content-Type: text/html; charset="UTF-8"',
    "Content-Transfer-Encoding: 8bit",
  ].join("\r\n");

  const body = `${headers}\r\n\r\n${mail.html}\r\n\r\n${mail.text}\r\n`;
  const accepted = await session.writeRaw(`${dotStuff(body)}\r\n.\r\n`);
  if (!accepted.startsWith("250")) throw new Error(`Message rejected: ${accepted}`);

  await session.cmd("QUIT");
  session.close();
}

import { desc, eq, count } from "drizzle-orm";
import { db } from "@/db";
import { requirements, users } from "@/db/schema";
import type { ClientRequirement } from "@/lib/site";

export function serializeRequirement(r: typeof requirements.$inferSelect): ClientRequirement {
  return {
    id: r.id,
    kind: (r.kind === "seller" ? "seller" : "buyer") as "buyer" | "seller",
    title: r.title,
    category: r.category,
    hsCode: r.hsCode,
    quantity: r.quantity,
    unit: r.unit,
    originCountry: r.originCountry,
    destinationCountry: r.destinationCountry,
    priceRange: r.priceRange,
    description: r.description,
    company: r.company,
    contactName: r.contactName,
    postedByName: r.postedByName,
    createdAt: r.createdAt.toISOString(),
  };
}

export async function getRequirements(kind?: "buyer" | "seller", limit = 100): Promise<ClientRequirement[]> {
  try {
    const query = db
      .select()
      .from(requirements)
      .orderBy(desc(requirements.createdAt))
      .limit(limit);
    const rows = kind ? await query.where(eq(requirements.kind, kind)) : await query;
    return rows.map(serializeRequirement);
  } catch {
    return [];
  }
}

export async function getCounts() {
  try {
    const [u] = await db.select({ n: count() }).from(users);
    const [b] = await db.select({ n: count() }).from(requirements).where(eq(requirements.kind, "buyer"));
    const [s] = await db.select({ n: count() }).from(requirements).where(eq(requirements.kind, "seller"));
    return { users: u?.n ?? 0, buyers: b?.n ?? 0, sellers: s?.n ?? 0 };
  } catch {
    return { users: 0, buyers: 0, sellers: 0 };
  }
}

import { getSessionUser, type SessionUser } from "@/lib/session";

export type AuthSession = {
  user: SessionUser;
};

export async function auth(): Promise<AuthSession | null> {
  const user = await getSessionUser();
  if (!user) return null;
  return { user };
}

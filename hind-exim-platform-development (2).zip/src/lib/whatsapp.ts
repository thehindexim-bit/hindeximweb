/**
 * WhatsApp message sending via Twilio WhatsApp Business API.
 * Falls back to wa.me deep-link + on-screen code if Twilio is not configured.
 */

export type WhatsAppConfig = {
  accountSid: string;
  authToken: string;
  fromNumber: string; // Twilio WhatsApp number, e.g. +14155238886
};

export function getWhatsAppConfig(): WhatsAppConfig | null {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const fromNumber = process.env.TWILIO_FROM_NUMBER;
  if (!accountSid || !authToken || !fromNumber) return null;
  return { accountSid, authToken, fromNumber };
}

export type SendResult = {
  ok: boolean;
  method: "twilio" | "wa-link";
  message?: string;
  error?: string;
  waUrl?: string;
};

/**
 * Sends a WhatsApp OTP message.
 * If Twilio is configured, sends via Twilio API.
 * Otherwise returns a wa.me URL so the user can open WhatsApp manually.
 */
export async function sendWhatsAppOtp(
  toPhone: string,
  code: string,
  purpose: "login" | "signup" = "login"
): Promise<SendResult> {
  const config = getWhatsAppConfig();
  const message = purpose === "signup"
    ? `*HIND EXIM — Verify Your Account*\n\nYour verification code is: *${code}*\n\nThis code expires in 10 minutes. Use it to complete your Hind Exim trade account setup.\n\n— Hind Exim Trade Desk`
    : `*HIND EXIM — Login Code*\n\nYour verification code is: *${code}*\n\nThis code expires in 10 minutes. Use it to sign in to your Hind Exim trade account.\n\n— Hind Exim Trade Desk`;

  const waUrl = `https://wa.me/${toPhone.replace(/^\+/, "")}?text=${encodeURIComponent(message)}`;

  if (config) {
    try {
      const res = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${config.accountSid}/Messages.json`,
        {
          method: "POST",
          headers: {
            Authorization: "Basic " + Buffer.from(`${config.accountSid}:${config.authToken}`).toString("base64"),
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            From: config.fromNumber,
            To: toPhone,
            Body: message,
          }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        return { ok: true, method: "twilio", message: data.sid };
      }
      return { ok: false, method: "twilio", error: data.message ?? "Twilio API error", waUrl };
    } catch (e) {
      return { ok: false, method: "twilio", error: String(e), waUrl };
    }
  }

  // No Twilio configured — return wa.me link so user can open WhatsApp manually
  return { ok: false, method: "wa-link", waUrl };
}

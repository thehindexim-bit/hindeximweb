import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import EmailAuthForm from "@/components/EmailAuthForm";
import Logo from "@/components/Logo";
import { SITE } from "@/lib/site";

export const metadata: Metadata = { title: "Log in — Hind Exim" };

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string; error?: string }>;
}) {
  const sp = await searchParams;
  const error =
    sp?.error === "invalid"
      ? "Wrong email or password."
      : sp?.error === "missing"
        ? "Enter email and password."
        : sp?.error || null;

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-28">
      <Image src="/images/port-dusk.jpg" alt="" fill className="pointer-events-none object-cover opacity-30" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-ink/85 via-ink/70 to-ink/95" />
      <div className="grid-bg pointer-events-none absolute inset-0 opacity-40" />

      <div className="relative z-20 w-full max-w-[460px]">
        <Link
          href="/"
          className="stencil mb-6 inline-flex items-center gap-2 rounded-full border border-line bg-panel/70 px-4 py-2 text-[10px] text-mist hover:text-gold"
        >
          <ArrowLeft size={11} /> Return home
        </Link>
        <div className="mb-8 flex justify-center">
          <Logo size={46} />
        </div>
        <div className="clip-notch border border-line bg-panel/90 p-8 backdrop-blur-xl sm:p-10">
          <p className="stencil text-[10px] text-gold">Member access</p>
          <h1 className="font-display mt-2 text-3xl font-black tracking-tight">Log in</h1>
          <p className="mt-2 text-[13px] text-mist">Use your email and password.</p>
          <div className="mt-7">
            <EmailAuthForm mode="login" error={error} />
          </div>
        </div>
        <p className="stencil mt-6 text-center text-[9px] text-dim">Trade desk · {SITE.phoneDisplay}</p>
      </div>
    </div>
  );
}

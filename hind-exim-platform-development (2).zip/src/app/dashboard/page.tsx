import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { requirements, users } from "@/db/schema";
import { serializeRequirement } from "@/lib/data";
import DashboardClient from "@/components/DashboardClient";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Trade Console — Hind Exim" };

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ kind?: string }>;
}) {
  const session = await auth();
  if (!session?.user?.email) redirect("/login?callbackUrl=/dashboard");

  const sp = await searchParams;
  const initialKind = sp?.kind === "seller" ? "seller" : "buyer";
  const userId = Number(session.user.id) || 0;
  const email = session.user.email;

  let myItems = [] as ReturnType<typeof serializeRequirement>[];
  let lastLoginAt: string | null = null;
  try {
    const rows = await db
      .select()
      .from(requirements)
      .where(eq(requirements.userId, userId))
      .orderBy(desc(requirements.createdAt))
      .limit(50);
    myItems = rows.map(serializeRequirement);
    const [u] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    lastLoginAt = u?.lastLoginAt ? u.lastLoginAt.toISOString() : null;
  } catch {
    /* first boot */
  }

  return (
    <div className="grid-bg relative min-h-screen">
      <div className="mx-auto max-w-[1400px] px-4 pb-24 pt-28 sm:px-6 lg:px-10">
        <DashboardClient
          user={{
            name: session.user.name ?? email,
            email,
            role: session.user.role,
            lastLoginAt,
          }}
          items={myItems}
          initialKind={initialKind}
        />
      </div>
    </div>
  );
}

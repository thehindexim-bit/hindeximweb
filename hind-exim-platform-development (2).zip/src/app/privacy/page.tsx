import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ShieldAlert, ShieldCheck } from "lucide-react";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Policy — Hind Exim",
  description:
    "How Hind Exim collects, uses and protects personal information, and our position on fraudulent activity on the trade platform.",
};

const UPDATED = "19 October 2026";

export default function PrivacyPage() {
  return (
    <div className="grid-bg relative min-h-screen">
      <div className="mx-auto max-w-[860px] px-4 pb-28 pt-32 sm:px-6">
        <Link
          href="/"
          className="stencil mb-8 inline-flex items-center gap-2 rounded-full border border-line bg-panel/70 px-4 py-2 text-[10px] text-mist hover:border-gold/50 hover:text-gold"
        >
          <ArrowLeft size={11} /> Return home
        </Link>

        <p className="stencil text-[11px] text-gold">Legal</p>
        <h1 className="font-display mt-3 text-[clamp(2.2rem,5vw,3.6rem)] font-black leading-[0.98] tracking-tight">
          PRIVACY POLICY
        </h1>
        <p className="mt-4 text-[14px] text-mist">
          Hind Exim Trade Services · {SITE.base}
          <br />
          Last updated: {UPDATED}
        </p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-leaf/40 bg-leaf/10 p-5">
            <p className="flex items-center gap-2 font-display text-[15px] font-bold text-leaf">
              <ShieldCheck size={18} /> Safety is our top priority
            </p>
            <p className="mt-2 text-[13px] leading-relaxed text-mist">
              We design this platform to protect your account, personal data and trade conversations. We
              take reasonable technical and organisational steps to keep information secure.
            </p>
          </div>
          <div className="rounded-2xl border border-gold/40 bg-gold/10 p-5">
            <p className="flex items-center gap-2 font-display text-[15px] font-bold text-gold">
              <ShieldAlert size={18} /> Fraud disclaimer
            </p>
            <p className="mt-2 text-[13px] leading-relaxed text-mist">
              Hind Exim is a trade facilitation desk. We are <strong className="text-bone">not responsible</strong>{" "}
              for fraudulent activity, fake mandates, unpaid cargo, or misrepresentation by any buyer,
              seller or third party you deal with.
            </p>
          </div>
        </div>

        <article className="prose-hind mt-12 space-y-10 text-[14.5px] leading-[1.75] text-mist">
          <Section n="01" title="Who we are">
            <p>
              This Privacy Policy applies to the website, trade boards, enquiry forms and related services
              operated by <strong className="text-bone">{SITE.legal}</strong> (“Hind Exim”, “we”, “us”,
              “our”). Our trade desk can be reached on{" "}
              <a href={SITE.phoneHref} className="text-gold hover:underline">
                {SITE.phoneDisplay}
              </a>{" "}
              or WhatsApp via the same number.
            </p>
            <p>
              By creating an account, posting a requirement, submitting a freight enquiry, or otherwise
              using this platform, you agree to this Policy.
            </p>
          </Section>

          <Section n="02" title="Information we collect">
            <p>We may collect:</p>
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li>
                <strong className="text-bone">Account data</strong> — full name, email address, password
                (stored only as a one-way hash), and optional phone number.
              </li>
              <li>
                <strong className="text-bone">Trade data</strong> — buy/sell enquiries, commodity, HS
                code, quantity, origin/destination, company name, contact person, and messages you send
                through our forms.
              </li>
              <li>
                <strong className="text-bone">Supplier applications</strong> — company details, sector,
                commodity and supporting notes submitted for admin review.
              </li>
              <li>
                <strong className="text-bone">Technical data</strong> — IP address, browser type, device,
                pages visited, and timestamps (including login events).
              </li>
              <li>
                <strong className="text-bone">Cookies</strong> — a session cookie so you stay logged in,
                and a small preference cookie so the header can show “My account”.
              </li>
            </ul>
            <p className="mt-3">
              We do not ask for bank account numbers, card PANs, OTPs, or private keys. Never send those
              to anyone claiming to represent Hind Exim except through channels you have independently
              verified.
            </p>
          </Section>

          <Section n="03" title="How we use information">
            <ul className="list-disc space-y-2 pl-5">
              <li>To create and maintain your account and keep you signed in.</li>
              <li>To route buy/sell and freight enquiries to our trade desk (including via WhatsApp).</li>
              <li>To publish or review listings you ask us to place on buyer/seller boards.</li>
              <li>To contact you about a mandate, shipment or account issue.</li>
              <li>To protect the platform against abuse, spam and unauthorised access.</li>
              <li>To comply with applicable law if we are legally required to disclose information.</li>
            </ul>
            <p className="mt-3">
              We do not sell your personal information. We do not run third-party advertising networks on
              this site.
            </p>
          </Section>

          <Section n="04" title="WhatsApp and phone communications">
            <p>
              When you submit a buy requirement, sell offer or freight quote, the details you enter may be
              sent to our desk on WhatsApp ({SITE.phoneDisplay}) so we can respond quickly. That message
              may include your name, email, phone and trade specifications.
            </p>
            <p>
              WhatsApp is operated by Meta. Their processing is governed by WhatsApp’s own terms and
              privacy policy. Do not include information in a form that you would not be comfortable
              sending in a business chat.
            </p>
          </Section>

          <Section n="05" title="Sharing and processors">
            <p>We may share data only with:</p>
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li>Our internal trade, operations and admin staff who need it to serve you.</li>
              <li>Infrastructure providers that host this website and database, under contract.</li>
              <li>
                Counterparties you explicitly ask us to introduce (for example a verified mill or import
                house) — only to the extent needed to progress that deal.
              </li>
              <li>Authorities if required by law, court order or to prevent serious harm.</li>
            </ul>
          </Section>

          <Section n="06" title="Safety first — how we protect you">
            <p>
              <strong className="text-leaf">Your safety is a top priority.</strong> We work to reduce risk
              by:
            </p>
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li>Hashing passwords; we cannot read your password back.</li>
              <li>Using session cookies that are not exposed to other websites.</li>
              <li>Requiring unique emails so accounts are not casually cloned.</li>
              <li>Reviewing supplier listing requests in an admin panel before they go live.</li>
              <li>Keeping a single published desk number so you can verify who you are speaking to.</li>
            </ul>
            <p className="mt-3">
              No website can guarantee absolute security. You must also protect your inbox, password and
              devices, and treat unexpected payment instructions with caution.
            </p>
          </Section>

          <Section n="07" title="Fraud, scams and limitation of liability">
            <p>
              Hind Exim provides a matching, documentation and logistics desk. We are{" "}
              <strong className="text-bone">not a bank, escrow agent, insurer or guarantor</strong> unless
              a separate written contract says otherwise.
            </p>
            <p>
              <strong className="text-gold">
                If any fraudulent, deceptive or criminal activity occurs — including fake buyers or
                sellers, forged documents, cargo diversion, non-payment, advance-fee scams, impersonation
                of Hind Exim, or misuse of listings — Hind Exim, its owners, employees and contractors
                are not responsible and accept no liability for resulting loss.
              </strong>
            </p>
            <p>You agree that:</p>
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li>
                You will independently verify counterparties, banks, vessels and documents before paying
                or shipping.
              </li>
              <li>
                You will not rely solely on a listing, WhatsApp message or website badge as proof of
                authenticity.
              </li>
              <li>
                Hind Exim does not control third parties who register, post or reply on this platform.
              </li>
              <li>
                Any introduction we make is commercial information, not a warranty of performance or
                honesty.
              </li>
            </ul>
            <p className="mt-3">
              If you suspect fraud, stop the transaction and contact the desk on {SITE.phoneDisplay} and,
              where appropriate, your bank and local law enforcement. We will cooperate reasonably with
              genuine investigations, subject to law.
            </p>
          </Section>

          <Section n="08" title="Your responsibilities">
            <ul className="list-disc space-y-2 pl-5">
              <li>Provide accurate information. Do not impersonate another person or company.</li>
              <li>Do not post illegal goods, sanctioned trades or misleading HS / quality claims.</li>
              <li>Keep your password confidential. You are responsible for activity on your account.</li>
              <li>
                Do not use this site to harvest contacts, spam, or run investment, crypto or “too good to
                be true” schemes.
              </li>
            </ul>
          </Section>

          <Section n="09" title="Retention">
            <p>
              We keep account and enquiry records for as long as your account is active and for a
              reasonable period afterwards for dispute handling, audit and legal compliance. You may ask
              us to close your account; we may retain limited records where the law requires it.
            </p>
          </Section>

          <Section n="10" title="Your rights">
            <p>
              Subject to applicable Indian law, you may request access to the personal data we hold about
              you, correction of inaccurate data, or deletion of your account. Write to the desk from
              your registered email or call {SITE.phoneDisplay}. We may need to verify it is you before
              acting.
            </p>
          </Section>

          <Section n="11" title="Cookies">
            <p>
              Essential cookies keep you logged in. Disabling them may log you out. We do not use
              third-party ad cookies. Browser settings can block cookies; the site may then not remember
              your session.
            </p>
          </Section>

          <Section n="12" title="Children">
            <p>
              This platform is for business users. It is not directed at children under 18. We do not
              knowingly collect data from minors.
            </p>
          </Section>

          <Section n="13" title="International use">
            <p>
              Servers and staff may process data in India and in other countries where our hosting
              providers operate. Cross-border trade by definition involves counterparties abroad. You
              consent to this processing when you use the service.
            </p>
          </Section>

          <Section n="14" title="Changes">
            <p>
              We may update this Policy. The “Last updated” date at the top will change. Continued use of
              the platform after an update means you accept the revised Policy.
            </p>
          </Section>

          <Section n="15" title="Contact">
            <p>
              Hind Exim Trade Services
              <br />
              {SITE.base}
              <br />
              Phone / WhatsApp:{" "}
              <a href={SITE.phoneHref} className="text-gold hover:underline">
                {SITE.phoneDisplay}
              </a>
            </p>
            <p className="mt-3 text-[13px] text-dim">
              This Policy is provided for transparency. It is not legal advice. For a specific contract,
              ask the desk for written terms.
            </p>
          </Section>
        </article>
      </div>
    </div>
  );
}

function Section({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="font-display flex items-baseline gap-3 text-xl font-extrabold tracking-tight text-bone">
        <span className="stencil text-[10px] text-gold">{n}</span>
        {title}
      </h2>
      <div className="mt-3 space-y-3">{children}</div>
    </section>
  );
}

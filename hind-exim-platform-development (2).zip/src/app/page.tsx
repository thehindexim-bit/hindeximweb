import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight, FileCheck, Handshake, Phone, Search, Ship } from "lucide-react";
import { Suspense } from "react";
import Hero from "@/components/Hero";
import Reveal from "@/components/Reveal";
import ListingCard from "@/components/ListingCard";
import WelcomeBanner from "@/components/WelcomeBanner";
import { getCounts, getRequirements } from "@/lib/data";
import { SERVICES, SITE, TICKER_ITEMS, type ServiceSlug } from "@/lib/site";

export const dynamic = "force-dynamic";

const SERVICE_ICONS: Record<ServiceSlug, React.ReactNode> = {
  "freight-forwarding": <Ship size={22} />,
  "buyer-sourcing": <Handshake size={22} />,
  "seller-sourcing": <Search size={22} />,
  "merchant-exports": <FileCheck size={22} />,
};

function Ticker() {
  const row = [...TICKER_ITEMS, ...TICKER_ITEMS];
  return (
    <div className="relative overflow-hidden border-y border-line bg-panel/60 py-4">
      <div className="marquee-track">
        {row.map((t, i) => (
          <span key={i} className="stencil flex items-center gap-6 whitespace-nowrap px-6 text-[10px] text-mist">
            {t}
            <span className="h-1.5 w-1.5 rotate-45 bg-gold/60" aria-hidden />
          </span>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-ink to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-ink to-transparent" />
    </div>
  );
}

export default async function Home() {
  const [counts, buyers, sellers] = await Promise.all([
    getCounts(),
    getRequirements("buyer", 3),
    getRequirements("seller", 3),
  ]);

  return (
    <div>
      <Suspense fallback={null}>
        <WelcomeBanner />
      </Suspense>
      <Hero liveCount={counts.buyers + counts.sellers} />
      <Ticker />

      {/* SERVICES */}
      <section id="services" className="relative scroll-mt-24">
        <div className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10 lg:py-28">
          <Reveal>
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div>
                <p className="stencil text-[11px] text-gold">What we move · who we match</p>
                <h2 className="font-display mt-4 text-[clamp(1.9rem,4.2vw,3.4rem)] font-black leading-[1.02] tracking-tight">
                  FOUR SERVICES.
                  <br />
                  <span className="text-outline">ONE TRADE DESK.</span>
                </h2>
              </div>
              <p className="max-w-sm text-[14px] leading-relaxed text-mist">
                Everything between a factory in India and a warehouse overseas —
                cargo, counterparts and compliance — runs through this desk.
              </p>
            </div>
          </Reveal>

          <div className="mt-14 grid gap-5 md:grid-cols-2">
            {SERVICES.map((s, i) => {
              const serviceHref =
                s.slug === "freight-forwarding"
                  ? "/freight-forwarding"
                  : s.slug === "buyer-sourcing"
                  ? "/buyers"
                  : s.slug === "seller-sourcing"
                  ? "/sellers"
                  : "/#services";

              return (
                <Reveal key={s.slug} delay={i * 0.08}>
                  <div className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-panel/70 p-8 transition-all duration-300 hover:-translate-y-1 hover:border-gold/45">
                    <span className="stencil absolute right-7 top-7 text-[10px] text-dim">/{s.index}</span>
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-gold/30 bg-gold/10 text-gold transition-colors group-hover:bg-gold group-hover:text-ink">
                      {SERVICE_ICONS[s.slug]}
                    </div>
                    <h3 className="font-display mt-6 text-2xl font-extrabold tracking-tight text-bone group-hover:text-gold">
                      {s.title}
                    </h3>
                    <p className="mt-1.5 text-[13px] font-medium text-mist">{s.tagline}</p>
                    <p className="mt-4 text-[13.5px] leading-relaxed text-mist/90">{s.description}</p>
                    <ul className="mt-6 grid grid-cols-1 gap-2 sm:grid-cols-2">
                      {s.points.map((p) => (
                        <li key={p} className="flex items-center gap-2.5 text-[12.5px] text-bone/80">
                          <span className="h-1 w-1 rotate-45 bg-gold" aria-hidden />
                          {p}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-8 border-t border-line2 pt-5">
                      <Link
                        href={serviceHref}
                        className="inline-flex items-center gap-2 text-[13px] font-bold text-gold transition-colors hover:text-saffron"
                      >
                        Explore {s.title} details <ArrowUpRight size={14} />
                      </Link>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* LIVE BOARD */}
      <section className="relative border-y border-line bg-abyss/60">
        <div className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10 lg:py-24">
          <Reveal>
            <div className="flex flex-wrap items-end justify-between gap-6">
              <div>
                <p className="stencil text-[11px] text-gold">Live trade board</p>
                <h2 className="font-display mt-4 text-[clamp(1.9rem,4.2vw,3.4rem)] font-black leading-[1.02] tracking-tight">
                  WHO&rsquo;S BUYING.
                  <br />
                  <span className="text-outline">WHO&rsquo;S SELLING.</span>
                </h2>
              </div>
              <div className="flex gap-3">
                <Link href="/buyers" className="clip-notch flex items-center gap-2 border border-gold/45 bg-gold/10 px-5 py-3 text-[13px] font-semibold text-gold transition-colors hover:bg-gold hover:text-ink">
                  Buyer board <ArrowUpRight size={14} />
                </Link>
                <Link href="/sellers" className="clip-notch flex items-center gap-2 border border-line bg-panel px-5 py-3 text-[13px] font-semibold text-bone transition-colors hover:border-gold hover:text-gold">
                  Seller board <ArrowUpRight size={14} />
                </Link>
              </div>
            </div>
          </Reveal>

          <div className="mt-12 grid gap-10 lg:grid-cols-2">
            <Reveal>
              <div>
                <p className="stencil mb-4 flex items-center gap-2 text-[10px] text-gold">
                  <span className="h-1.5 w-1.5 rounded-full bg-gold" /> Fresh buy mandates
                </p>
                <div className="space-y-4">
                  {buyers.length === 0 && <EmptyBoardNote label="No buy mandates yet — post the first one." href="/dashboard?kind=buyer" />}
                  {buyers.map((b) => (
                    <ListingCard key={b.id} item={b} />
                  ))}
                </div>
              </div>
            </Reveal>
            <Reveal delay={0.1}>
              <div>
                <p className="stencil mb-4 flex items-center gap-2 text-[10px] text-leaf">
                  <span className="h-1.5 w-1.5 rounded-full bg-leaf" /> Fresh supply offers
                </p>
                <div className="space-y-4">
                  {sellers.length === 0 && <EmptyBoardNote label="No supply offers yet — list yours first." href="/dashboard?kind=seller" />}
                  {sellers.map((s) => (
                    <ListingCard key={s.id} item={s} />
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section>
        <div className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10 lg:py-24">
          <Reveal>
            <p className="stencil text-[11px] text-gold">How a deal moves</p>
            <h2 className="font-display mt-4 max-w-3xl text-[clamp(1.8rem,3.6vw,2.8rem)] font-black leading-tight tracking-tight">
              FROM REQUIREMENT TO BILL OF LADING IN FOUR MOVES.
            </h2>
          </Reveal>
          <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {[
              { n: "01", t: "Post or call", d: "Drop your requirement on the board or ring the desk. We scope product, volume and terms within hours." },
              { n: "02", t: "Match & verify", d: "We shortlist verified buyers or suppliers, run KYC, and align on price, quality and payment security." },
              { n: "03", t: "Contract & document", d: "Proforma, LC / advance terms, export documents and compliance — prepared and checked by the desk." },
              { n: "04", t: "Ship & settle", d: "Freight booked, cargo tracked, documents couriered and remittance closed. You get one point of contact." },
            ].map((s, i) => (
              <Reveal key={s.n} delay={i * 0.07} className="h-full">
                <div className="flex h-full flex-col bg-panel/80 p-7">
                  <span className="font-display text-3xl font-black text-gold/90">{s.n}</span>
                  <h3 className="font-display mt-4 text-lg font-bold text-bone">{s.t}</h3>
                  <p className="mt-2.5 text-[13px] leading-relaxed text-mist">{s.d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden border-t border-line">
        <Image src="/images/port-dusk.jpg" alt="Container port at dusk" fill className="object-cover opacity-45" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/95 via-ink/75 to-ink/40" />
        <div className="relative mx-auto max-w-[1400px] px-4 py-24 sm:px-6 lg:px-10 lg:py-32">
          <Reveal>
            <p className="stencil text-[11px] text-gold">Ready when you are</p>
            <h2 className="font-display mt-5 max-w-3xl text-[clamp(2rem,5vw,4.2rem)] font-black leading-[1.0] tracking-tight">
              ONE NUMBER FOR
              <br />
              <span className="text-gold">EVERY SHIPMENT.</span>
            </h2>
            <p className="mt-5 max-w-lg text-[15px] leading-relaxed text-mist">
              No departments, no ticket queues. Freight, sourcing and export execution —
              one desk, one call, one accountable team.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <a href={SITE.phoneHref} className="clip-notch flex items-center gap-3 bg-gold px-8 py-4 text-[15px] font-bold text-ink transition-colors hover:bg-saffron">
                <Phone size={16} />
                Call {SITE.phoneDisplay}
              </a>
              <Link href="/signup" className="clip-notch flex items-center gap-3 border border-bone/25 bg-ink/40 px-8 py-4 text-[15px] font-bold text-bone backdrop-blur transition-colors hover:border-gold hover:text-gold">
                Open a trade account <ArrowUpRight size={15} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}

function EmptyBoardNote({ label, href }: { label: string; href: string }) {
  return (
    <Link
      href={href}
      className="block rounded-2xl border border-dashed border-line bg-panel/40 px-6 py-10 text-center text-[13px] text-mist transition-colors hover:border-gold/50 hover:text-gold"
    >
      {label}
    </Link>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Boxes,
  CheckCircle2,
  Factory,
  FileCheck,
  HelpCircle,
  PackageCheck,
  Phone,
  Scale,
  ShieldCheck,
  Truck,
  Warehouse,
} from "lucide-react";
import { auth } from "@/lib/auth";
import BoardClient from "@/components/BoardClient";
import OpenTradeButton from "@/components/OpenTradeButton";
import SupplierRequestForm from "@/components/SupplierRequestForm";
import Reveal from "@/components/Reveal";
import { getRequirements } from "@/lib/data";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Seller Sourcing & Verified Indian Suppliers — Hind Exim",
  description:
    "Direct factory-gate sourcing across India: Basmati rice mills, spice processors, textile clusters, chemical plants, and engineering manufacturers. Verified suppliers, audited quality, one desk: +91 91803 98801.",
};

const SELLER_PILLARS = [
  {
    icon: <Factory className="text-leaf" size={20} />,
    title: "Factory-Direct Verification",
    desc: "We perform on-site audits of manufacturing capacity, machinery, certifications (ISO, GMP, APEDA, FSSAI), and environmental compliance before listing.",
  },
  {
    icon: <PackageCheck className="text-leaf" size={20} />,
    title: "Pre-Shipment Quality Control",
    desc: "Coordinate independent third-party inspections for moisture, grain count, chemical assay, tensile strength, and packaging integrity.",
  },
  {
    icon: <Scale className="text-leaf" size={20} />,
    title: "Transparent Factory-Gate Pricing",
    desc: "We eliminate multi-layer local brokers so overseas buyers purchase at true origin rates, while sellers secure guaranteed export remittances.",
  },
  {
    icon: <FileCheck className="text-leaf" size={20} />,
    title: "Export Packaging & Compliance",
    desc: "Guidance on palletization, phytosanitary certificates, fumigation certificates, certificate of origin (COO), and customs tariff classifications.",
  },
];

const SECTORS = [
  {
    sector: "Agro Commodities & Grains",
    origin: "Punjab, Haryana, MP, Gujarat",
    examples: "Basmati Rice 1121/1509/Sugandha, Non-Basmati (IR64, PR11), Wheat, Maize, Soymeal",
  },
  {
    sector: "Spices & Condiments",
    origin: "Kerala, Tamil Nadu, Andhra, Rajasthan",
    examples: "Turmeric (Salem/Erode), Cumin (Unjha), Green Cardamom, Red Chilli (Teja/Sannam), Coriander",
  },
  {
    sector: "Textiles, Yarns & Made-ups",
    origin: "Tirupur, Surat, Karur, Panipat",
    examples: "100% Cotton Yarn 20s-60s, Melange Yarns, Handloom Bed Linen, Terry Towels, Technical Textiles",
  },
  {
    sector: "Engineering & Metal Scrap",
    origin: "Jamnagar, Ludhiana, Coimbatore, Pune",
    examples: "Brass Hardware, Copper Millberry Wire Scrap, Cast Iron Castings, Industrial Fasteners, Flanges",
  },
  {
    sector: "Pharmaceuticals & APIs",
    origin: "Hyderabad, Ahmedabad, Baddi, Maharashtra",
    examples: "Paracetamol API, Ibuprofen, Nutraceutical extracts, Finished dosage forms (Tablets/Capsules)",
  },
  {
    sector: "Chemicals & Minerals",
    origin: "Dahej, Ankleshwar, Rajasthan",
    examples: "Caustic Soda, Dyes & Intermediates, Quartz Powder, Feldspar, Bentonite, Activated Carbon",
  },
];

const SELLER_FAQS = [
  {
    q: "How can Indian manufacturers join Hind Exim as a verified supplier?",
    a: "Indian mills and factories can sign up via email OTP and submit a 'Request to be Listed as Supplier' form. Our admin team reviews your company details, certifications, and capacity before approving your listing on the public seller board.",
  },
  {
    q: "Can sellers post directly without admin approval?",
    a: "No. All supplier submissions go through an admin review process. Once approved, your company appears on the live seller board visible to overseas buyers.",
  },
  {
    q: "Does Hind Exim buy directly or act as an intermediary?",
    a: "Both models are available. Under Merchant Exports, Hind Exim buys under our export house and exports directly to overseas buyers. Under Buyer-Seller matching, we facilitate direct contracts with commission structures.",
  },
  {
    q: "Can Hind Exim handle factory-to-port logistics for sellers?",
    a: "Yes. Our Freight Forwarding division arranges container placement directly at your factory gate (ICD or stuffing at port), CHA customs clearance, and road transit to Nhava Sheva, Mundra, or Chennai.",
  },
];

export default async function SellersPage() {
  const [items, session] = await Promise.all([getRequirements("seller"), auth()]);
  const isSignedIn = Boolean(session?.user);

  return (
    <div className="grid-bg relative min-h-screen">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden border-b border-line bg-gradient-to-b from-abyss via-ink to-ink pt-32 pb-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <div className="grid items-center gap-12 lg:grid-cols-[1.25fr_1fr]">
            <div>
              <Link
                href="/"
                className="stencil mb-5 inline-flex items-center gap-2 rounded-full border border-line bg-panel/70 px-4 py-2 text-[10px] text-mist transition-colors hover:border-gold/50 hover:text-gold"
              >
                <ArrowLeft size={11} /> Return home
              </Link>
              <div className="flex flex-wrap items-center gap-3">
                <span className="stencil rounded-full border border-leaf/40 bg-leaf/10 px-4 py-1.5 text-[10px] text-leaf">
                  Seller Sourcing Desk
                </span>
                <span className="stencil rounded-full border border-line bg-panel/70 px-4 py-1.5 text-[10px] text-mist">
                  Pan-India Factory Network
                </span>
              </div>

              <h1 className="font-display mt-6 text-[clamp(2.4rem,5.5vw,4.5rem)] font-black leading-[0.98] tracking-tight text-bone">
                VERIFIED INDIAN
                <br />
                <span className="text-leaf">SUPPLIERS & FACTORIES.</span>
              </h1>

              <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-mist">
                Source directly from audited Indian processors, mills, and manufacturers.
                Zero layer of middlemen, guaranteed factory-gate inspection, and export-compliant
                documentation managed end-to-end by Hind Exim.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <OpenTradeButton
                  kind="seller"
                  className="clip-notch flex items-center gap-2 bg-leaf px-7 py-3.5 text-[14px] font-bold text-ink transition-colors hover:brightness-110"
                >
                  <ArrowUpRight size={16} />
                  Request to be Listed as Supplier
                </OpenTradeButton>
                <a
                  href={SITE.phoneHref}
                  className="clip-notch flex items-center gap-3 border border-line bg-panel px-6 py-3.5 text-[14px] font-semibold text-bone transition-colors hover:border-gold hover:text-gold"
                >
                  <Phone size={15} className="text-gold" />
                  Call trade desk: {SITE.phoneDisplay}
                </a>
              </div>

              <div className="mt-10 grid grid-cols-3 gap-4 border-t border-line/60 pt-6">
                <div>
                  <p className="font-display text-2xl font-black text-leaf">{items.length}</p>
                  <p className="stencil mt-1 text-[9px] text-dim">Active supply offers</p>
                </div>
                <div>
                  <p className="font-display text-2xl font-black text-bone">6+</p>
                  <p className="stencil mt-1 text-[9px] text-dim">Core export sectors</p>
                </div>
                <div>
                  <p className="font-display text-2xl font-black text-bone">100%</p>
                  <p className="stencil mt-1 text-[9px] text-dim">Audited suppliers</p>
                </div>
              </div>
            </div>

            {/* Verification checklist card */}
            <div className="rounded-2xl border border-line bg-panel/85 p-7 shadow-[0_30px_90px_-30px_rgba(0,0,0,0.8)] backdrop-blur">
              <div className="flex items-center justify-between">
                <span className="stencil text-[10px] text-leaf">Supplier Onboarding Protocol</span>
                <span className="stencil rounded-full border border-leaf/40 bg-leaf/10 px-3 py-1 text-[9px] text-leaf">
                  Admin Approved
                </span>
              </div>
              <div className="mt-6 space-y-4">
                {[
                  { t: "Factory Audit & Production Capacity", d: "Physical inspection of machinery, storage warehouses, and monthly export tonnage capability." },
                  { t: "Statutory & Export Certifications", d: "GST, APEDA, Spice Board, FSSAI, ISO 9001/22000 verification." },
                  { t: "Lab Testing & Assays", d: "COA (Certificate of Analysis) verification via NABL-accredited laboratories before contract execution." },
                  { t: "Packaging & Containerization Support", d: "Export-grade 25/50kg PP bags, vacuum packs, palletized drums, and stuffing supervision." },
                ].map((item, idx) => (
                  <div key={item.t} className="flex gap-4 rounded-xl border border-line2 bg-abyss/60 p-3.5">
                    <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-leaf" />
                    <div>
                      <p className="text-[13px] font-bold text-bone">{item.t}</p>
                      <p className="mt-0.5 text-[12px] text-mist">{item.d}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* LIVE SELLERS BOARD */}
      <section className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:px-10">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="stencil text-[11px] text-leaf">Live Supply Board</p>
            <h2 className="font-display mt-2 text-[clamp(1.8rem,3.8vw,2.8rem)] font-black text-bone">
              ACTIVE SELLER LISTINGS & OFFERS
            </h2>
            <p className="mt-1 text-[13.5px] text-mist">
              Only admin-approved supplier listings appear here. Every listing is verified by the Hind Exim desk.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-leaf opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-leaf" />
            </span>
            <span className="stencil text-[10px] text-leaf">Admin Verified Stock</span>
          </div>
        </div>

        <BoardClient items={items} kind="seller" />
      </section>

      {/* REQUEST TO BE LISTED FORM (for signed-in sellers) */}
      {(
        <section className="border-t border-line bg-abyss/70 py-20">
          <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="stencil text-[11px] text-gold">Supplier Application</p>
                <h2 className="font-display mt-2 text-[clamp(1.8rem,3.8vw,2.8rem)] font-black text-bone">
                  REQUEST TO BE LISTED AS SUPPLIER
                </h2>
                <p className="mt-1 text-[13.5px] text-mist">
                  Submit your company details. Our admin team will review and approve your listing before it goes live on the seller board.
                </p>
              </div>
            </div>

            <div className="mx-auto max-w-3xl">
              <SupplierRequestForm />
              <p className="mt-4 text-center text-[12px] text-mist">
                After submission, your request goes to the admin panel for review.
              </p>
            </div>
          </div>
        </section>
      )}

      {/* MANUFACTURING HUBS */}
      <section className="border-t border-line py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <Reveal>
            <p className="stencil text-[11px] text-leaf">Source At Origin</p>
            <h2 className="font-display mt-3 text-[clamp(1.8rem,3.5vw,2.8rem)] font-black text-bone">
              INDIAN MANUFACTURING & AGRO CLUSTERS
            </h2>
          </Reveal>

          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {SECTORS.map((s) => (
              <div key={s.sector} className="rounded-2xl border border-line bg-panel/70 p-6 transition-colors hover:border-leaf/50">
                <span className="stencil text-[10px] text-leaf">{s.origin}</span>
                <h3 className="font-display mt-2 text-lg font-bold text-bone">{s.sector}</h3>
                <p className="mt-3 text-[13px] leading-relaxed text-mist">{s.examples}</p>
                <div className="mt-5 border-t border-line2 pt-4">
                  <a
                    href={SITE.phoneHref}
                    className="flex items-center justify-between text-[12px] font-semibold text-leaf hover:underline"
                  >
                    <span>Request audit report</span>
                    <ArrowRight size={13} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SELLER PILLARS */}
      <section className="border-t border-line py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <Reveal>
            <p className="stencil text-[11px] text-leaf">Quality Assurance Protocol</p>
            <h2 className="font-display mt-3 text-[clamp(1.8rem,3.5vw,2.8rem)] font-black text-bone">
              HOW HIND EXIM GUARDS YOUR PROCUREMENT
            </h2>
          </Reveal>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {SELLER_PILLARS.map((p, i) => (
              <Reveal key={p.title} delay={i * 0.08} className="h-full">
                <div className="flex h-full flex-col rounded-2xl border border-line bg-panel/70 p-6 transition-colors hover:border-leaf/50">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-leaf/30 bg-leaf/10">
                    {p.icon}
                  </div>
                  <h3 className="font-display mt-5 text-lg font-bold text-bone">{p.title}</h3>
                  <p className="mt-2.5 text-[13px] leading-relaxed text-mist">{p.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FAQS */}
      <section className="border-t border-line bg-abyss/60 py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <p className="stencil text-[11px] text-leaf">Frequently Asked Questions</p>
          <h2 className="font-display mt-3 text-[clamp(1.8rem,3.5vw,2.8rem)] font-black text-bone">
            SELLER SOURCING CLARIFICATIONS
          </h2>

          <div className="mt-10 grid gap-5 md:grid-cols-2">
            {SELLER_FAQS.map((f) => (
              <div key={f.q} className="rounded-2xl border border-line bg-panel/70 p-6">
                <h3 className="font-display flex items-start gap-3 text-base font-bold text-bone">
                  <HelpCircle size={18} className="mt-0.5 shrink-0 text-leaf" />
                  {f.q}
                </h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-mist">{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* UNIFORM CONTACT BANNER */}
      <section className="border-t border-line bg-gradient-to-r from-abyss via-panel to-abyss py-16">
        <div className="mx-auto max-w-[1400px] px-4 text-center sm:px-6 lg:px-10">
          <p className="stencil text-[11px] text-leaf">Direct Factory Representation</p>
          <h2 className="font-display mt-3 text-[clamp(1.8rem,4vw,3rem)] font-black text-bone">
            ARE YOU AN AUDITED INDIAN MANUFACTURER?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-[14px] text-mist">
            Submit your supplier request through our dashboard. Overseas buyers review our verified
            seller offers every day.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <a
              href={SITE.phoneHref}
              className="clip-notch flex items-center gap-3 bg-leaf px-8 py-4 text-[15px] font-bold text-ink transition-colors hover:brightness-110"
            >
              <Phone size={16} />
              Call trade desk: {SITE.phoneDisplay}
            </a>
            <OpenTradeButton
              kind="seller"
              className="clip-notch flex items-center gap-2 border border-line bg-panel px-7 py-4 text-[14px] font-semibold text-bone hover:border-leaf hover:text-leaf"
            >
              Submit supplier request <ArrowRight size={15} />
            </OpenTradeButton>
          </div>
        </div>
      </section>
    </div>
  );
}

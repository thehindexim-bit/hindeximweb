import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import AdminClient from "@/components/AdminClient";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin — Hind Exim" };

export default async function AdminPage() {
  const session = await auth();
  if (!session?.user) redirect("/login?callbackUrl=/admin");
  if (session.user.role !== "admin") redirect("/dashboard");

  return (
    <div className="grid-bg relative min-h-screen">
      <div className="mx-auto max-w-[1400px] px-4 pb-24 pt-28 sm:px-6 lg:px-10">
        <AdminClient adminPhone={session.user.email ?? "desk"} />
      </div>
    </div>
  );
}

import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import StaffLoginForm from "@/components/StaffLoginForm";

export const metadata: Metadata = { title: "Desk — Hind Exim", robots: { index: false, follow: false } };

export default async function StaffPage() {
  const session = await auth();
  if (session?.user?.role === "admin") redirect("/admin");
  if (session?.user) redirect("/dashboard");

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4 py-28">
      <div className="grid-bg absolute inset-0 opacity-40" />
      <div className="relative w-full max-w-[400px] clip-notch border border-line bg-panel/90 p-8">
        <p className="stencil text-[10px] text-dim">Internal</p>
        <h1 className="font-display mt-2 text-2xl font-black">Desk access</h1>
        <div className="mt-6">
          <StaffLoginForm />
        </div>
      </div>
    </div>
  );
}

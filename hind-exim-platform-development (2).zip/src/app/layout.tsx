import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Providers from "@/components/Providers";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CallFloat from "@/components/CallFloat";
import ReturnHome from "@/components/ReturnHome";
import { TradeFormProvider } from "@/components/TradeFormProvider";
import { SITE } from "@/lib/site";
import { auth } from "@/lib/auth";
import { connection } from "next/server";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Hind Exim — Export, Import & Global Trade Services",
  description:
    "Hind Exim is an Indian export-import house offering freight forwarding, buyer sourcing, seller sourcing and merchant exports. One desk, one call: +91 91803 98801.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  await connection();
  const session = await auth();
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=IBM+Plex+Mono:wght@400;500;600&family=Space+Grotesk:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-ink text-bone antialiased">
        <Providers user={session?.user ?? null}>
          <TradeFormProvider>
            <div className="tricolor fixed inset-x-0 top-0 z-[60] h-[3px]" aria-hidden />
            <Navbar />
            <main>{children}</main>
            <Footer phoneDisplay={SITE.phoneDisplay} phoneHref={SITE.phoneHref} />
            <CallFloat />
            <ReturnHome />
          </TradeFormProvider>
        </Providers>
      </body>
    </html>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import {
  ArrowDownRight,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Building2,
  CheckCircle2,
  FileCheck,
  Globe2,
  Handshake,
  HelpCircle,
  Phone,
  Plane,
  ShieldCheck,
  Ship,
  Sparkles,
  TrendingUp,
  Truck,
  Users,
} from "lucide-react";
import { auth } from "@/lib/auth";
import BoardClient from "@/components/BoardClient";
import OpenTradeButton from "@/components/OpenTradeButton";
import Reveal from "@/components/Reveal";
import { getRequirements } from "@/lib/data";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Buyer Sourcing & Global Buy Mandates — Hind Exim",
  description:
    "Direct access to verified international import houses actively buying Indian agricultural commodities, spices, textiles, chemicals, engineering goods, and pharma. Trade desk: +91 91803 98801.",
};

const MARKETS = [
  { region: "Middle East & GCC", ports: "Jebel Ali, Dammam, Hamad, Sohar", share: "35% Volume" },
  { region: "European Union", ports: "Rotterdam, Antwerp, Hamburg, Genoa", share: "24% Volume" },
  { region: "North & East Africa", ports: "Alexandria, Mombasa, Dar es Salaam", share: "18% Volume" },
  { region: "Americas & Caribbean", ports: "Santos, New York, Houston, Veracruz", share: "15% Volume" },
  { region: "Southeast Asia", ports: "Singapore, Port Klang, Tanjung Priok", share: "8% Volume" },
];

const BUYER_PERKS = [
  {
    icon: <ShieldCheck className="text-gold" size={20} />,
    title: "100% KYC & Mandate Verification",
    desc: "Every buyer requirement is vetted with corporate registry checks, import history verification, and active trade references before publishing.",
  },
  {
    icon: <FileCheck className="text-gold" size={20} />,
    title: "LOI, ICPO & LC Support",
    desc: "We align Irrevocable Corporate Purchase Orders, Letters of Credit (LC at sight / Usance), and DP terms so transactions are safe on both sides.",
  },
  {
    icon: <Handshake className="text-gold" size={20} />,
    title: "Single Desk Representation",
    desc: "Indian exporters don't deal with 20 middlemen. Hind Exim acts as the central negotiating desk, aligning specs, certifications, and delivery terms.",
  },
  {
    icon: <Ship className="text-gold" size={20} />,
    title: "Integrated Freight Booking",
    desc: "Every closed mandate moves seamlessly to our ocean & air freight forwarders, ensuring CIF/CFR commitments are met on schedule.",
  },
];

const FAQS = [
  {
    q: "How does Hind Exim verify buyers?",
    a: "We verify company incorporation, tax/VAT numbers, port clearance track record, and commercial banking references. Only genuine buy mandates with real budget and specifications are accepted onto the board.",
  },
  {
    q: "Can international buyers post directly?",
    a: "Yes. Overseas import houses can create an account via email OTP or call our desk directly. Our trade managers assist with spec formatting, HS codes, and Indian supplier shortlisting.",
  },
  {
    q: "How are payment terms protected?",
    a: "We structure deals primarily on Confirmed Irrevocable Letters of Credit (LC at Sight) or Advance TT with bank guarantees, backed by DGFT / ECGC compliance guidelines.",
  },
  {
    q: "What commodities have the highest buyer activity?",
    a: "Basmati rice (1121 / 1509), Indian spices (turmeric, cumin, cardamom, chilli), organic cotton yarn & apparel, agro-chemicals, pharma APIs, and non-ferrous metals.",
  },
];

export default async function BuyersPage() {
  const [items, session] = await Promise.all([getRequirements("buyer"), auth()]);

  return (
    <div className="grid-bg relative min-h-screen">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden border-b border-line bg-gradient-to-b from-abyss via-ink to-ink pt-32 pb-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <div className="grid items-center gap-12 lg:grid-cols-[1.25fr_1fr]">
            <div>
              <Link
                href="/"
                className="stencil mb-5 inline-flex items-center gap-2 rounded-full border border-line bg-panel/70 px-4 py-2 text-[10px] text-mist transition-colors hover:border-gold/50 hover:text-gold"
              >
                <ArrowLeft size={11} /> Return home
              </Link>
              <div className="flex flex-wrap items-center gap-3">
                <span className="stencil rounded-full border border-gold/40 bg-gold/10 px-4 py-1.5 text-[10px] text-gold">
                  Buyer Sourcing Desk
                </span>
                <span className="stencil rounded-full border border-line bg-panel/70 px-4 py-1.5 text-[10px] text-mist">
                  40+ Import Markets
                </span>
              </div>

              <h1 className="font-display mt-6 text-[clamp(2.4rem,5.5vw,4.5rem)] font-black leading-[0.98] tracking-tight text-bone">
                GLOBAL BUYER
                <br />
                <span className="text-gold">MANDATES & SOURCING.</span>
              </h1>

              <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-mist">
                Connect with qualified overseas import houses looking for Indian export commodities.
                Every inquiry is qualified by our Jaipur trade desk — with volume, destination port,
                and payment terms aligned before you quote.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <OpenTradeButton
                  kind="buyer"
                  className="clip-notch flex items-center gap-2 bg-gold px-7 py-3.5 text-[14px] font-bold text-ink transition-colors hover:bg-saffron"
                >
                  <ArrowDownRight size={16} />
                  Post a buy requirement
                </OpenTradeButton>
                <a
                  href={SITE.phoneHref}
                  className="clip-notch flex items-center gap-3 border border-line bg-panel px-6 py-3.5 text-[14px] font-semibold text-bone transition-colors hover:border-gold hover:text-gold"
                >
                  <Phone size={15} className="text-gold" />
                  Call trade desk: {SITE.phoneDisplay}
                </a>
              </div>

              <div className="mt-10 grid grid-cols-3 gap-4 border-t border-line/60 pt-6">
                <div>
                  <p className="font-display text-2xl font-black text-gold">{items.length}</p>
                  <p className="stencil mt-1 text-[9px] text-dim">Active buy mandates</p>
                </div>
                <div>
                  <p className="font-display text-2xl font-black text-bone">40+</p>
                  <p className="stencil mt-1 text-[9px] text-dim">Importing countries</p>
                </div>
                <div>
                  <p className="font-display text-2xl font-black text-bone">24h</p>
                  <p className="stencil mt-1 text-[9px] text-dim">Desk response time</p>
                </div>
              </div>
            </div>

            {/* Quick Mandate Card */}
            <div className="rounded-2xl border border-line bg-panel/85 p-7 shadow-[0_30px_90px_-30px_rgba(0,0,0,0.8)] backdrop-blur">
              <div className="flex items-center justify-between">
                <span className="stencil text-[10px] text-gold">How Buyer Sourcing Works</span>
                <span className="stencil rounded-full border border-gold/40 bg-gold/10 px-3 py-1 text-[9px] text-gold">
                  Step-by-step
                </span>
              </div>
              <div className="mt-6 space-y-4">
                {[
                  { n: "01", t: "Overseas Buyer submits LOI", d: "Product specs, volume (MT/FCL), target CIF port, packaging & target pricing." },
                  { n: "02", t: "Desk Audits & Verifies", d: "Commercial registration check, trade references, and financial guarantee review." },
                  { n: "03", t: "Matched to Indian Producers", d: "We connect APEDA, DGFT & ISO certified Indian factories directly to the buyer." },
                  { n: "04", t: "Contract & Freight Execution", d: "Hind Exim handles samples, proforma, LC vetting, and booking onto ocean vessels." },
                ].map((s) => (
                  <div key={s.n} className="flex gap-4 rounded-xl border border-line2 bg-abyss/60 p-3.5">
                    <span className="font-display text-lg font-black text-gold">{s.n}</span>
                    <div>
                      <p className="text-[13px] font-bold text-bone">{s.t}</p>
                      <p className="mt-0.5 text-[12px] text-mist">{s.d}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* LIVE BUYERS BOARD */}
      <section className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:px-10">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="stencil text-[11px] text-gold">Live Trade Board</p>
            <h2 className="font-display mt-2 text-[clamp(1.8rem,3.8vw,2.8rem)] font-black text-bone">
              ACTIVE BUY REQUIREMENTS
            </h2>
            <p className="mt-1 text-[13.5px] text-mist">
              Filter by commodity category, HS code, or destination country. Every mandate is open for direct quotation.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-leaf opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-leaf" />
            </span>
            <span className="stencil text-[10px] text-leaf">Live Desk Verified</span>
          </div>
        </div>

        <BoardClient items={items} kind="buyer" />
      </section>

      {/* SOURCING PILLARS */}
      <section className="border-t border-line bg-abyss/70 py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <Reveal>
            <p className="stencil text-[11px] text-gold">Why Exporters Trust Us</p>
            <h2 className="font-display mt-3 text-[clamp(1.8rem,3.5vw,2.8rem)] font-black text-bone">
              THE HIND EXIM BUYER SOURCING ADVANTAGE
            </h2>
          </Reveal>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {BUYER_PERKS.map((p, i) => (
              <Reveal key={p.title} delay={i * 0.08} className="h-full">
                <div className="flex h-full flex-col rounded-2xl border border-line bg-panel/70 p-6 transition-colors hover:border-gold/45">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-gold/30 bg-gold/10">
                    {p.icon}
                  </div>
                  <h3 className="font-display mt-5 text-lg font-bold text-bone">{p.title}</h3>
                  <p className="mt-2.5 text-[13px] leading-relaxed text-mist">{p.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ACTIVE DESTINATION MARKETS */}
      <section className="border-t border-line py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="stencil text-[11px] text-gold">Target Corridors</p>
              <h2 className="font-display mt-3 text-[clamp(1.8rem,3.5vw,2.8rem)] font-black text-bone">
                KEY IMPORT MARKETS WE SERVE
              </h2>
            </div>
            <p className="max-w-md text-[13.5px] text-mist">
              Direct shipping lines and customs channels operating weekly out of Nhava Sheva, Mundra,
              Chennai, and Hazira ports.
            </p>
          </div>

          <div className="mt-10 grid gap-4 md:grid-cols-3 lg:grid-cols-5">
            {MARKETS.map((m) => (
              <div key={m.region} className="rounded-xl border border-line bg-panel/70 p-5">
                <div className="flex items-center justify-between">
                  <Globe2 size={16} className="text-gold" />
                  <span className="stencil text-[9px] text-dim">{m.share}</span>
                </div>
                <h3 className="font-display mt-3 text-base font-bold text-bone">{m.region}</h3>
                <p className="stencil mt-2 text-[10px] text-gold">{m.ports}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQS */}
      <section className="border-t border-line bg-abyss/60 py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <p className="stencil text-[11px] text-gold">Frequently Asked Questions</p>
          <h2 className="font-display mt-3 text-[clamp(1.8rem,3.5vw,2.8rem)] font-black text-bone">
            BUYER SOURCING CLARIFICATIONS
          </h2>

          <div className="mt-10 grid gap-5 md:grid-cols-2">
            {FAQS.map((f) => (
              <div key={f.q} className="rounded-2xl border border-line bg-panel/70 p-6">
                <h3 className="font-display flex items-start gap-3 text-base font-bold text-bone">
                  <HelpCircle size={18} className="mt-0.5 shrink-0 text-gold" />
                  {f.q}
                </h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-mist">{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* UNIFORM CONTACT BANNER */}
      <section className="border-t border-line bg-gradient-to-r from-abyss via-panel to-abyss py-16">
        <div className="mx-auto max-w-[1400px] px-4 text-center sm:px-6 lg:px-10">
          <p className="stencil text-[11px] text-gold">One Contact For Every Mandate</p>
          <h2 className="font-display mt-3 text-[clamp(1.8rem,4vw,3rem)] font-black text-bone">
            HAVE A SPECIFIC BUY REQUIREMENT TO POST?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-[14px] text-mist">
            Our trade specialists will format your mandate, run price discovery across Indian suppliers,
            and structure freight quotes within 24 hours.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <a
              href={SITE.phoneHref}
              className="clip-notch flex items-center gap-3 bg-gold px-8 py-4 text-[15px] font-bold text-ink transition-colors hover:bg-saffron"
            >
              <Phone size={16} />
              Call trade desk: {SITE.phoneDisplay}
            </a>
            <OpenTradeButton
              kind="buyer"
              className="clip-notch flex items-center gap-2 border border-line bg-panel px-7 py-4 text-[14px] font-semibold text-bone hover:border-gold hover:text-gold"
            >
              Post mandate online <ArrowRight size={15} />
            </OpenTradeButton>
          </div>
        </div>
      </section>
    </div>
  );
}

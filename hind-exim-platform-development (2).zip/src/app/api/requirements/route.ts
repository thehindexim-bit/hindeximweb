import { NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { requirements } from "@/db/schema";
import { serializeRequirement } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const kind = searchParams.get("kind");
  const mine = searchParams.get("mine");

  const conditions = [];
  if (kind === "buyer" || kind === "seller") conditions.push(eq(requirements.kind, kind));

  if (mine === "1") {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    conditions.push(eq(requirements.userId, Number(session.user.id)));
  }

  const rows = await db
    .select()
    .from(requirements)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(requirements.createdAt))
    .limit(200);

  return NextResponse.json({ items: rows.map(serializeRequirement) });
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.email) {
    return NextResponse.json({ error: "You must be signed in to post." }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const kind = body?.kind === "seller" ? "seller" : "buyer";
  const title = String(body?.title ?? "").trim();
  if (title.length < 3) {
    return NextResponse.json({ error: "Product / commodity title is required." }, { status: 400 });
  }

  const [created] = await db
    .insert(requirements)
    .values({
      kind,
      title,
      category: String(body?.category ?? "General").trim() || "General",
      hsCode: String(body?.hsCode ?? "").trim() || null,
      quantity: String(body?.quantity ?? "").trim() || null,
      unit: String(body?.unit ?? "").trim() || null,
      originCountry: String(body?.originCountry ?? "").trim() || null,
      destinationCountry: String(body?.destinationCountry ?? "").trim() || null,
      priceRange: String(body?.priceRange ?? "").trim() || null,
      description: String(body?.description ?? "").trim() || null,
      company: String(body?.company ?? "").trim() || null,
      contactName: String(body?.contactName ?? "").trim() || null,
      postedByName: session.user.name ?? session.user.email,
      postedByEmail: session.user.email,
      userId: Number(session.user.id) || null,
      status: "open",
    })
    .returning();

  return NextResponse.json({ ok: true, item: serializeRequirement(created) });
}

export async function DELETE(req: Request) {
  const session = await auth();
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

  const [row] = await db.select().from(requirements).where(eq(requirements.id, id)).limit(1);
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const isOwner = row.userId != null && String(row.userId) === session.user.id;
  const isAdmin = session.user.role === "admin";
  if (!isOwner && !isAdmin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  await db.delete(requirements).where(eq(requirements.id, id));
  return NextResponse.json({ ok: true });
}

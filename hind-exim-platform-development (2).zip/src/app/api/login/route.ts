import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { loginEvents, users } from "@/db/schema";
import { attachSessionCookies, publicUrl } from "@/lib/session";

export const dynamic = "force-dynamic";

async function readFields(req: Request) {
  const ctype = req.headers.get("content-type") ?? "";
  if (ctype.includes("application/json")) {
    const body = await req.json().catch(() => ({}));
    return {
      email: String(body?.email ?? "").trim(),
      password: String(body?.password ?? ""),
      isForm: false,
    };
  }
  const form = await req.formData().catch(() => null);
  return {
    email: String(form?.get("email") ?? "").trim(),
    password: String(form?.get("password") ?? ""),
    isForm: true,
  };
}

export async function POST(req: Request) {
  try {
    const { email: raw, password, isForm } = await readFields(req);
    if (!raw || !password) {
      if (isForm) return NextResponse.redirect(publicUrl(req, "/login?error=missing"), 303);
      return NextResponse.json({ error: "Enter email and password." }, { status: 400 });
    }

    let row;
    if (raw.toUpperCase() === "ADMIN") {
      const [admin] = await db.select().from(users).where(eq(users.username, "ADMIN")).limit(1);
      row = admin;
    } else {
      const [u] = await db.select().from(users).where(eq(users.email, raw.toLowerCase())).limit(1);
      row = u;
    }

    if (!row?.passwordHash || !(await bcrypt.compare(password, row.passwordHash))) {
      if (isForm) return NextResponse.redirect(publicUrl(req, "/login?error=invalid"), 303);
      return NextResponse.json({ error: "Wrong email or password." }, { status: 401 });
    }

    const user = {
      id: String(row.id),
      email: row.email ?? raw.toLowerCase(),
      name: row.name,
      role: row.role,
    };

    try {
      await db.insert(loginEvents).values({ email: user.email, provider: "email", userId: row.id });
      await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, row.id));
    } catch {
      /* ignore */
    }

    const dest = user.role === "admin" ? "/admin" : "/?welcome=1";
    const res = isForm
      ? NextResponse.redirect(publicUrl(req, dest), 303)
      : NextResponse.json({ ok: true, user, redirect: dest });
    attachSessionCookies(res, user);
    return res;
  } catch (e) {
    console.error("login failed", e);
    return NextResponse.json({ error: "Login failed. Try again." }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { loginEvents, users } from "@/db/schema";
import { attachSessionCookies, publicUrl } from "@/lib/session";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function readFields(req: Request) {
  const ctype = req.headers.get("content-type") ?? "";
  if (ctype.includes("application/json")) {
    const body = await req.json().catch(() => ({}));
    return {
      name: String(body?.name ?? "").trim(),
      email: String(body?.email ?? "").trim().toLowerCase(),
      password: String(body?.password ?? ""),
      confirm: String(body?.confirm ?? body?.password ?? ""),
      isForm: false,
    };
  }
  const form = await req.formData().catch(() => null);
  return {
    name: String(form?.get("name") ?? "").trim(),
    email: String(form?.get("email") ?? "").trim().toLowerCase(),
    password: String(form?.get("password") ?? ""),
    confirm: String(form?.get("confirm") ?? ""),
    isForm: true,
  };
}

export async function POST(req: Request) {
  try {
    const { name, email, password, confirm, isForm } = await readFields(req);

    const fail = (msg: string, code = 400) => {
      if (isForm) return NextResponse.redirect(publicUrl(req, `/signup?error=${encodeURIComponent(msg)}`), 303);
      return NextResponse.json({ error: msg }, { status: code });
    };

    if (name.length < 2) return fail("Please enter your full name.");
    if (!EMAIL_RE.test(email)) return fail("Enter a valid email address.");
    if (password.length < 6) return fail("Password must be at least 6 characters.");
    if (password !== confirm) return fail("Passwords do not match.");

    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) return fail("This email is already registered. Please log in.", 409);

    const passwordHash = await bcrypt.hash(password, 10);
    const [created] = await db
      .insert(users)
      .values({ name, email, passwordHash, role: "user", provider: "email" })
      .returning();

    const user = { id: String(created.id), email: created.email ?? email, name: created.name, role: created.role };
    try {
      await db.insert(loginEvents).values({ email: user.email, provider: "email", userId: created.id });
    } catch {
      /* ignore */
    }

    const res = isForm
      ? NextResponse.redirect(publicUrl(req, "/?welcome=signup"), 303)
      : NextResponse.json({ ok: true, user, redirect: "/?welcome=signup" });
    attachSessionCookies(res, user);
    return res;
  } catch (e) {
    const msg = String(e);
    if (msg.includes("unique") || msg.includes("duplicate")) {
      return NextResponse.redirect(publicUrl(req, "/signup?error=" + encodeURIComponent("This email is already registered. Please log in.")), 303);
    }
    console.error("signup failed", e);
    return NextResponse.json({ error: "Could not create account. Try again." }, { status: 500 });
  }
}

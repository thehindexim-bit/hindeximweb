import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { loginEvents } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await auth();
  if (!session?.user || session.user.role !== "admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const rows = await db.select().from(loginEvents).orderBy(desc(loginEvents.createdAt)).limit(200);
  return NextResponse.json({
    items: rows.map((r) => ({
      id: r.id,
      email: r.email,
      phone: r.email,
      provider: r.provider,
      createdAt: r.createdAt.toISOString(),
    })),
  });
}

import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { requirements } from "@/db/schema";
import { serializeRequirement } from "@/lib/data";

export const dynamic = "force-dynamic";

async function requireAdmin() {
  const session = await auth();
  if (!session?.user || session.user.role !== "admin") return null;
  return session;
}

export async function POST(req: Request) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const body = await req.json().catch(() => null);
  const kind = body?.kind === "seller" ? "seller" : "buyer";
  const title = String(body?.title ?? "").trim();
  if (title.length < 3) {
    return NextResponse.json({ error: "Product / commodity title is required." }, { status: 400 });
  }

  const [created] = await db
    .insert(requirements)
    .values({
      kind,
      title,
      category: String(body?.category ?? "General").trim() || "General",
      hsCode: String(body?.hsCode ?? "").trim() || null,
      quantity: String(body?.quantity ?? "").trim() || null,
      unit: String(body?.unit ?? "").trim() || null,
      originCountry: String(body?.originCountry ?? "").trim() || null,
      destinationCountry: String(body?.destinationCountry ?? "").trim() || null,
      priceRange: String(body?.priceRange ?? "").trim() || null,
      description: String(body?.description ?? "").trim() || null,
      company: String(body?.company ?? "").trim() || null,
      contactName: String(body?.contactName ?? "").trim() || null,
      postedByName: session.user.name ?? "Hind Exim",
      postedByEmail: session.user.email,
      userId: null,
      status: "open",
    })
    .returning();

  return NextResponse.json({ ok: true, item: serializeRequirement(created) });
}

export async function DELETE(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

  await db.delete(requirements).where(eq(requirements.id, id));
  return NextResponse.json({ ok: true });
}

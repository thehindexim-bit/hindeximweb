import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { desc } from "drizzle-orm";
import { supplierRequests } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await auth();
  if (!session?.user || session.user.role !== "admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const rows = await db
    .select()
    .from(supplierRequests)
    .orderBy(desc(supplierRequests.createdAt))
    .limit(200);

  return NextResponse.json({
    items: rows.map((r) => ({
      id: r.id,
      companyName: r.companyName,
      contactName: r.contactName,
      email: r.email,
      phone: r.phone,
      sector: r.sector,
      commodity: r.commodity,
      originCountry: r.originCountry,
      gstNumber: r.gstNumber,
      panNumber: r.panNumber,
      companyAddress: r.companyAddress,
      city: r.city,
      state: r.state,
      description: r.description,
      status: r.status,
      reviewedBy: r.reviewedBy,
      reviewedAt: r.reviewedAt ? r.reviewedAt.toISOString() : null,
      createdAt: r.createdAt.toISOString(),
    })),
  });
}

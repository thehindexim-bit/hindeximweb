import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { eq } from "drizzle-orm";
import { requirements, supplierRequests, users } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user || session.user.role !== "admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const numericId = Number(id);
  const body = await req.json().catch(() => null);
  const status = body?.status; // "approved" | "rejected"

  if (status !== "approved" && status !== "rejected") {
    return NextResponse.json({ error: "Invalid status. Must be 'approved' or 'rejected'." }, { status: 400 });
  }

  const [request] = await db
    .select()
    .from(supplierRequests)
    .where(eq(supplierRequests.id, numericId))
    .limit(1);

  if (!request) {
    return NextResponse.json({ error: "Supplier request not found." }, { status: 404 });
  }

  const now = new Date();

  if (status === "approved") {
    // Convert the approved supplier request into a public seller listing
    const [created] = await db
      .insert(requirements)
      .values({
        kind: "seller",
        title: `${request.companyName} — ${request.commodity} Supply`,
        category: request.sector,
        hsCode: null,
        quantity: null,
        unit: null,
        originCountry: request.originCountry,
        destinationCountry: null,
        priceRange: null,
        description: request.description ?? `Verified supplier of ${request.commodity} from ${request.originCountry}.`,
        company: request.companyName,
        contactName: request.contactName,
        postedByName: "Hind Exim Admin",
        postedByEmail: session.user.email,
        userId: null,
        status: "open",
      })
      .returning();

    await db
      .update(supplierRequests)
      .set({ status: "approved", reviewedBy: Number(session.user.id), reviewedAt: now })
      .where(eq(supplierRequests.id, numericId));

    return NextResponse.json({
      ok: true,
      status: "approved",
      listingId: created.id,
    });
  } else {
    await db
      .update(supplierRequests)
      .set({ status: "rejected", reviewedBy: Number(session.user.id), reviewedAt: now })
      .where(eq(supplierRequests.id, numericId));

    return NextResponse.json({ ok: true, status: "rejected" });
  }
}

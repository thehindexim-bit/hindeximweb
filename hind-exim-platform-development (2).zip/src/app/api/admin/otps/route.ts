import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { otpOutbox } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await auth();
  if (!session?.user || session.user.role !== "admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  try {
    const rows = await db.select().from(otpOutbox).orderBy(desc(otpOutbox.createdAt)).limit(50);
    return NextResponse.json({
      items: rows.map((r) => ({
        id: r.id,
        phone: r.phone,
        code: r.code,
        waUrl: r.waUrl,
        status: r.status,
        createdAt: r.createdAt.toISOString(),
      })),
    });
  } catch {
    return NextResponse.json({ items: [] });
  }
}

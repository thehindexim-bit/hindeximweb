import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { consumeTicket, createTicket } from "@/lib/otp";
import { normalizePhone } from "@/lib/phone";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const phone = normalizePhone(String(body?.phone ?? "").trim());
    const name = String(body?.name ?? "").trim();
    const password = String(body?.password ?? "");
    const ticket = String(body?.ticket ?? "");

    if (name.length < 2) {
      return NextResponse.json({ error: "Please enter your full name." }, { status: 400 });
    }
    if (password.length < 6) {
      return NextResponse.json({ error: "Password must be at least 6 characters." }, { status: 400 });
    }
    if (!(await consumeTicket(ticket, phone))) {
      return NextResponse.json({ error: "Session expired. Please verify your phone again." }, { status: 401 });
    }

    const [existing] = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    const passwordHash = await bcrypt.hash(password, 10);

    if (existing) {
      await db.update(users).set({ name, passwordHash, provider: "phone" }).where(eq(users.id, existing.id));
    } else {
      await db.insert(users).values({
        name,
        phone,
        username: null,
        email: null,
        passwordHash,
        role: "user",
        provider: "phone",
      });
    }

    const loginTicket = await createTicket(phone, "login");
    return NextResponse.json({ ok: true, ticket: loginTicket, phone });
  } catch (e) {
    console.error("otp complete failed", e);
    return NextResponse.json({ error: "Something went wrong. Try again." }, { status: 500 });
  }
}

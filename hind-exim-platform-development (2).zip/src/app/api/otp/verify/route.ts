import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createTicket, verifyOtp } from "@/lib/otp";
import { normalizePhone } from "@/lib/phone";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const phone = normalizePhone(String(body?.phone ?? "").trim());
    const code = String(body?.code ?? "").trim();

    if (!phone || !code) {
      return NextResponse.json({ error: "Phone and code are required." }, { status: 400 });
    }

    const result = await verifyOtp(phone, code);
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 400 });
    }

    const [u] = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    const ticket = await createTicket(phone, u ? "login" : "signup");

    return NextResponse.json({
      ok: true,
      ticket,
      phone,
      known: Boolean(u),
      needsProfile: !u || !u.name || u.name.length < 2,
    });
  } catch (e) {
    console.error("otp verify failed", e);
    return NextResponse.json({ error: "Something went wrong. Try again." }, { status: 500 });
  }
}

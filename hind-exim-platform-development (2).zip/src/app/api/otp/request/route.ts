import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { requestOtp } from "@/lib/otp";
import { isValidPhone, normalizePhone } from "@/lib/phone";
import { sendWhatsAppOtp } from "@/lib/whatsapp";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const raw = String(body?.phone ?? "").trim();
    if (!isValidPhone(raw)) {
      return NextResponse.json({ error: "Enter a valid 10-digit Indian phone number." }, { status: 400 });
    }
    const phone = normalizePhone(raw);

    const result = await requestOtp(phone);
    if ("error" in result) {
      return NextResponse.json({ error: result.error }, { status: 429 });
    }

    const [existing] = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    const known = Boolean(existing);

    const whatsapp = await sendWhatsAppOtp(phone, result.code, known ? "login" : "signup");

    try {
      const { otpOutbox } = await import("@/db/schema");
      await db.insert(otpOutbox).values({
        phone,
        code: result.code,
        waUrl: whatsapp.waUrl ?? null,
        status: whatsapp.ok ? "sent" : "pending",
      });
    } catch {
      // outbox is optional
    }

    return NextResponse.json({
      ok: true,
      phone,
      known,
      expiresInMinutes: 10,
      whatsappSent: whatsapp.ok,
      method: whatsapp.method,
      code: result.code,
      waUrl: whatsapp.waUrl ?? null,
    });
  } catch (e) {
    console.error("otp request failed", e);
    return NextResponse.json({ error: "Something went wrong. Try again." }, { status: 500 });
  }
}

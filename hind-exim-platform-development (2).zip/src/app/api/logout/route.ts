import { NextResponse } from "next/server";
import { clearSessionCookies, publicUrl } from "@/lib/session";

export async function POST() {
  return clearSessionCookies(NextResponse.json({ ok: true }));
}

export async function GET(req: Request) {
  return clearSessionCookies(NextResponse.redirect(publicUrl(req, "/")));
}

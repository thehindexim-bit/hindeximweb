import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import {
  Anchor,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Boxes,
  CheckCircle2,
  Clock,
  Compass,
  FileCheck,
  FileText,
  Globe2,
  HelpCircle,
  MapPin,
  Phone,
  Plane,
  ShieldCheck,
  Ship,
  Truck,
  Warehouse,
} from "lucide-react";
import FreightQuoteForm from "@/components/FreightQuoteForm";
import Reveal from "@/components/Reveal";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Freight Forwarding & Ocean Air Logistics — Hind Exim",
  description:
    "End-to-end multimodal logistics from India: FCL ocean freight, LCL consolidations, air cargo, CHA customs clearance, and inland road haulage. Live booking desk: +91 91803 98801.",
};

const FREIGHT_SERVICES = [
  {
    icon: <Ship size={24} className="text-gold" />,
    title: "Ocean Freight — FCL (Full Container Load)",
    desc: "Guaranteed container slots and contracted rates with premier shipping lines (Maersk, MSC, CMA CGM, Hapag-Lloyd, COSCO, ONE). 20ft, 40ft Standard, High Cube, and Open Tops.",
    specs: ["Pan-India port coverage", "Direct vessel sailings", "Detention & demurrage waivers", "Hazardous (DG) cargo certified"],
  },
  {
    icon: <Boxes size={24} className="text-gold" />,
    title: "Ocean Freight — LCL (Less than Container Load)",
    desc: "Cost-effective groupage consolidations for shipments from 1 CBM to 15 CBM. Regular weekly stuffing at major CFS hubs across Nhava Sheva, Mundra, and Chennai.",
    specs: ["Zero minimum weight barrier", "Dedicated CFS de-stuffing", "Safe cargo palletization", "Transparent destination charges"],
  },
  {
    icon: <Plane size={24} className="text-gold" />,
    title: "Air Cargo & Priority Charter",
    desc: "Time-critical export solutions for perishables, pharmaceuticals, garments, and urgent spares. Direct flights out of Delhi (DEL), Mumbai (BOM), Bengaluru (BLR), and Ahmedabad (AMD).",
    specs: ["Next-flight-out booking", "Temperature-controlled (Reefer)", "IATA compliant documentation", "Airport-to-airport & door delivery"],
  },
  {
    icon: <FileCheck size={24} className="text-gold" />,
    title: "CHA Customs Clearance & Documentation",
    desc: "Licensed in-house Custom House Agent (CHA) operations. We handle Bill of Lading (BL), Shipping Bills, e-BRC generation, Certificate of Origin (COO), and RoDTEP/Drawback claims.",
    specs: ["DGFT & ICEGATE filing", "Phytosanitary & Fumigation", "Factory stuffing permissions", "Bonded warehouse clearance"],
  },
  {
    icon: <Truck size={24} className="text-gold" />,
    title: "Inland Multi-Modal Haulage (ICD to Port)",
    desc: "GPS-tracked fleet of 20ft and 40ft container trailers connecting Inland Container Depots (ICD Jaipur, ICD Ludhiana, ICD Tughlakabad, ICD Dadri, ICD Moradabad) directly to coastal gateways.",
    specs: ["Factory-gate container placement", "Real-time GPS vehicle tracking", "Rail transit corridor booking", "Cargo insurance coverage"],
  },
  {
    icon: <Warehouse size={24} className="text-gold" />,
    title: "Bonded Warehousing & Packaging",
    desc: "Secure storage, pallet wrapping, heat-treated wood pallets (ISPM-15), container lashing, and pre-loading inspection at port CFS facilities.",
    specs: ["ISPM-15 export palletizing", "Moisture-barrier silica lining", "Drum / bag container stuffing", "CCTV 24×7 bonded yard"],
  },
];

const LANES = [
  {
    corridor: "Nhava Sheva / Mundra → Jebel Ali (UAE)",
    transit: "3 - 5 Days",
    frequency: "Daily Sailings",
    type: "FCL / LCL / Reefer",
  },
  {
    corridor: "Mundra → Rotterdam / Hamburg (Europe)",
    transit: "24 - 28 Days",
    frequency: "3x Weekly",
    type: "Direct Ocean Lines",
  },
  {
    corridor: "Nhava Sheva → New York / Norfolk (USA East Coast)",
    transit: "28 - 32 Days",
    frequency: "2x Weekly",
    type: "FCL All-Water / Miniland",
  },
  {
    corridor: "Chennai / Krishnapatnam → Port Klang / Singapore",
    transit: "5 - 7 Days",
    frequency: "4x Weekly",
    type: "Direct Feeder & Mother Vessel",
  },
  {
    corridor: "Mundra → Mombasa / Dar es Salaam (East Africa)",
    transit: "12 - 16 Days",
    frequency: "Weekly",
    type: "Agro & Breakbulk Specialists",
  },
  {
    corridor: "Delhi (DEL) / Mumbai (BOM) → Worldwide Air",
    transit: "24 - 48 Hours",
    frequency: "Daily Flights",
    type: "Express Air Freight",
  },
];

const FREIGHT_FAQS = [
  {
    q: "How fast can Hind Exim confirm a vessel slot?",
    a: "For standard trade lanes (Gulf, Europe, SE Asia), slot confirmation and booking reference numbers (SO) are issued within 4 to 12 hours of cargo readiness.",
  },
  {
    q: "Can Hind Exim handle factory stuffing at our premises?",
    a: "Yes. We arrange empty container pickup from port/ICD yards, trailer placement at your manufacturing site, excise/customs seal verification, and return haulage to the gateway port.",
  },
  {
    q: "What documents do you need to book ocean freight?",
    a: "We only require your Commercial Invoice, Packing List, GST invoice, and export documentation. Our CHA team handles the Shipping Bill generation, VGM filing, and BL draft issuance.",
  },
  {
    q: "Do you offer cargo marine insurance?",
    a: "Yes. Hind Exim provides Institute Cargo Clauses (A) all-risk insurance covering door-to-door transit, piracy, general average, and port handling damage.",
  },
];

export default function FreightForwardingPage() {
  return (
    <div className="grid-bg relative min-h-screen">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden border-b border-line bg-gradient-to-b from-abyss via-ink to-ink pt-32 pb-20">
        <div className="absolute inset-0">
          <Image
            src="/images/hero-ship.jpg"
            alt="Cargo vessel"
            fill
            priority
            className="object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-ink via-ink/80 to-ink" />
        </div>

        <div className="relative mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <Link
                href="/"
                className="stencil mb-5 inline-flex items-center gap-2 rounded-full border border-line bg-panel/70 px-4 py-2 text-[10px] text-mist transition-colors hover:border-gold/50 hover:text-gold"
              >
                <ArrowLeft size={11} /> Return home
              </Link>
              <div className="flex flex-wrap items-center gap-3">
                <span className="stencil rounded-full border border-gold/40 bg-gold/10 px-4 py-1.5 text-[10px] text-gold">
                  Multimodal Freight Desk
                </span>
                <span className="stencil rounded-full border border-line bg-panel/70 px-4 py-1.5 text-[10px] text-mist">
                  Pan-India Ports & ICDs
                </span>
              </div>

              <h1 className="font-display mt-6 text-[clamp(2.4rem,5.5vw,4.5rem)] font-black leading-[0.98] tracking-tight text-bone">
                OCEAN & AIR
                <br />
                <span className="text-gold">FREIGHT FORWARDING.</span>
              </h1>

              <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-mist">
                Direct container allocation, priority air slots, factory trailer placement, and
                licensed CHA customs filing. From ICD factory gate to foreign discharge berth —
                managed under one accountable bill of lading.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <a
                  href="#quote"
                  className="clip-notch flex items-center gap-2 bg-gold px-7 py-3.5 text-[14px] font-bold text-ink transition-colors hover:bg-saffron"
                >
                  <Ship size={16} />
                  Get live freight rate
                </a>
                <a
                  href={SITE.phoneHref}
                  className="clip-notch flex items-center gap-3 border border-line bg-panel px-6 py-3.5 text-[14px] font-semibold text-bone transition-colors hover:border-gold hover:text-gold"
                >
                  <Phone size={15} className="text-gold" />
                  Freight hotline: {SITE.phoneDisplay}
                </a>
              </div>

              <div className="mt-10 grid grid-cols-3 gap-4 border-t border-line/60 pt-6">
                <div>
                  <p className="font-display text-2xl font-black text-gold">18+</p>
                  <p className="stencil mt-1 text-[9px] text-dim">Major gateway lanes</p>
                </div>
                <div>
                  <p className="font-display text-2xl font-black text-bone">24/7</p>
                  <p className="stencil mt-1 text-[9px] text-dim">Vessel booking desk</p>
                </div>
                <div>
                  <p className="font-display text-2xl font-black text-bone">100%</p>
                  <p className="stencil mt-1 text-[9px] text-dim">CHA customs coverage</p>
                </div>
              </div>
            </div>

            {/* FREIGHT QUOTE CALCULATOR FORM */}
            <div id="quote">
              <FreightQuoteForm />
            </div>
          </div>
        </div>
      </section>

      {/* CORE LOGISTICS SERVICES */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="stencil text-[11px] text-gold">End-To-End Capabilities</p>
              <h2 className="font-display mt-2 text-[clamp(1.9rem,4vw,3rem)] font-black text-bone">
                FULL-SPECTRUM CARGO OPERATIONS
              </h2>
            </div>
            <p className="max-w-md text-[13.5px] text-mist">
              Whether you ship 500 FCL containers of basmati rice or a single pallet of spices by air,
              we maintain the same rigorous standards of tracking and compliance.
            </p>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {FREIGHT_SERVICES.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.06} className="h-full">
              <div className="flex h-full flex-col rounded-2xl border border-line bg-panel/70 p-7 transition-colors hover:border-gold/50">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-gold/30 bg-gold/10">
                  {s.icon}
                </div>
                <h3 className="font-display mt-5 text-lg font-bold text-bone">{s.title}</h3>
                <p className="mt-2.5 text-[13px] leading-relaxed text-mist">{s.desc}</p>
                <div className="mt-auto border-t border-line2 pt-5">
                  <ul className="space-y-1.5">
                    {s.specs.map((sp) => (
                      <li key={sp} className="flex items-center gap-2 text-[12px] text-bone/80">
                        <CheckCircle2 size={12} className="text-gold" />
                        {sp}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* MAJOR SHIPPING LANES & TRANSIT TIMES */}
      <section className="border-t border-line bg-abyss/70 py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <Reveal>
            <p className="stencil text-[11px] text-gold">Schedules & Transit</p>
            <h2 className="font-display mt-2 text-[clamp(1.8rem,3.8vw,2.8rem)] font-black text-bone">
              PRIMARY INDIAN EXPORT TRADE CORRIDORS
            </h2>
          </Reveal>

          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {LANES.map((l) => (
              <div key={l.corridor} className="rounded-xl border border-line bg-panel/75 p-5 transition-colors hover:border-gold/45">
                <div className="flex items-center justify-between">
                  <span className="stencil rounded-full border border-gold/40 bg-gold/10 px-3 py-1 text-[9px] text-gold">
                    {l.frequency}
                  </span>
                  <span className="stencil text-[10px] text-dim">{l.type}</span>
                </div>
                <h3 className="font-display mt-4 text-base font-bold text-bone">{l.corridor}</h3>
                <div className="mt-4 flex items-center justify-between border-t border-line2 pt-3 text-[12px]">
                  <span className="text-mist flex items-center gap-1.5">
                    <Clock size={12} className="text-gold" /> Port-to-Port:
                  </span>
                  <span className="font-bold text-gold">{l.transit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FREIGHT FAQS */}
      <section className="border-t border-line py-20">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <p className="stencil text-[11px] text-gold">Operations FAQ</p>
          <h2 className="font-display mt-2 text-[clamp(1.8rem,3.8vw,2.8rem)] font-black text-bone">
            FREIGHT FORWARDING QUESTIONS
          </h2>

          <div className="mt-10 grid gap-5 md:grid-cols-2">
            {FREIGHT_FAQS.map((f) => (
              <div key={f.q} className="rounded-2xl border border-line bg-panel/70 p-6">
                <h3 className="font-display flex items-start gap-3 text-base font-bold text-bone">
                  <HelpCircle size={18} className="mt-0.5 shrink-0 text-gold" />
                  {f.q}
                </h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-mist">{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* UNIFORM CONTACT BANNER */}
      <section className="border-t border-line bg-gradient-to-r from-abyss via-panel to-abyss py-16">
        <div className="mx-auto max-w-[1400px] px-4 text-center sm:px-6 lg:px-10">
          <p className="stencil text-[11px] text-gold">Uniform Trade Contact</p>
          <h2 className="font-display mt-3 text-[clamp(1.8rem,4vw,3rem)] font-black text-bone">
            NEED IMMEDIATE VESSEL BOOKING OR RATE CHECK?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-[14px] text-mist">
            One phone number routes your inquiry straight to our central shipping controllers in Jaipur.
            No automated switchboards, no call queues.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <a
              href={SITE.phoneHref}
              className="clip-notch flex items-center gap-3 bg-gold px-8 py-4 text-[15px] font-bold text-ink transition-colors hover:bg-saffron"
            >
              <Phone size={16} />
              Call shipping desk: {SITE.phoneDisplay}
            </a>
            <a
              href="#quote"
              className="clip-notch flex items-center gap-2 border border-line bg-panel px-7 py-4 text-[14px] font-semibold text-bone hover:border-gold hover:text-gold"
            >
              Fill out freight spec form <ArrowRight size={15} />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

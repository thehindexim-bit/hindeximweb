"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { useState } from "react";
import { Menu, Phone, X } from "lucide-react";
import Logo from "@/components/Logo";
import AccountMenu from "@/components/AccountMenu";
import { SITE } from "@/lib/site";

const LINKS = [
  { href: "/freight-forwarding", label: "Freight Forwarding" },
  { href: "/buyers", label: "Buyer Sourcing" },
  { href: "/sellers", label: "Seller Sourcing" },
  { href: "/#services", label: "All Services" },
  { href: "/#contact", label: "Contact" },
];

export default function Navbar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed inset-x-0 top-[3px] z-50 border-b border-line bg-ink/80 backdrop-blur-xl">
      <div className="mx-auto flex h-[68px] max-w-[1400px] items-center justify-between gap-4 px-4 sm:px-6 lg:px-10">
        <div className="flex items-center gap-3">
          <Link href="/" aria-label="Hind Exim home" className="shrink-0">
            <Logo />
          </Link>
          {user && <AccountMenu user={user} logout={logout} />}
        </div>

        <nav className="hidden items-center gap-8 lg:flex">
          {LINKS.map((l) => (
            <Link
              key={l.label}
              href={l.href}
              className={`stencil text-[11px] transition-colors hover:text-gold ${
                pathname === l.href ? "text-gold" : "text-mist"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={SITE.phoneHref}
            className="group flex items-center gap-2.5 rounded-full border border-line bg-panel px-4 py-2 transition-all hover:border-gold/60"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-leaf opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-leaf" />
            </span>
            <Phone size={13} className="text-gold" />
            <span className="hidden text-[13px] font-medium tracking-wide text-bone group-hover:text-gold sm:inline">
              {SITE.phoneDisplay}
            </span>
          </a>

          {!user && (
            <>
              <a href="/login" className="rounded-lg px-3 py-2 text-[13px] font-semibold text-mist hover:text-gold">
                Log in
              </a>
              <a
                href="/signup"
                className="rounded-xl bg-gold px-5 py-2.5 text-[13px] font-semibold text-ink hover:bg-saffron"
              >
                Sign up
              </a>
            </>
          )}
        </div>

        <button
          className="rounded-md border border-line p-2 text-bone md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-line bg-ink/95 px-5 py-5 backdrop-blur-xl md:hidden">
          <div className="flex flex-col gap-4">
            {LINKS.map((l) => (
              <Link
                key={l.label}
                href={l.href}
                onClick={() => setOpen(false)}
                className="stencil text-[12px] text-mist transition-colors hover:text-gold"
              >
                {l.label}
              </Link>
            ))}
            <a href={SITE.phoneHref} className="flex items-center gap-2 text-[14px] text-gold">
              <Phone size={14} /> {SITE.phoneDisplay}
            </a>
            <div className="flex gap-3 pt-2">
              {user ? (
                <div className="sm:hidden">
                  <AccountMenu user={user} logout={logout} />
                </div>
              ) : (
                <>
                  <Link href="/login" className="rounded-full border border-line px-4 py-2 text-[13px] text-mist">
                    Log in
                  </Link>
                  <Link href="/signup" className="clip-notch bg-gold px-4 py-2 text-[13px] font-semibold text-ink">
                    Sign up
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

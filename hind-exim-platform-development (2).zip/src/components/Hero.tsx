"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowDownRight, ArrowUpRight, Phone } from "lucide-react";
import { SITE } from "@/lib/site";
import { useTradeForm } from "@/components/TradeFormProvider";

const EASE = [0.16, 1, 0.3, 1] as const;

export default function Hero({ liveCount }: { liveCount: number }) {
  const { openForm } = useTradeForm();
  return (
    <section className="relative flex min-h-[100svh] flex-col overflow-hidden">
      <div className="absolute inset-0">
        <Image
          src="/images/hero-ship.jpg"
          alt="Container ship crossing the ocean at night"
          fill
          priority
          className="object-cover object-center opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/78 to-ink/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/70" />
        <div className="grid-bg absolute inset-0 opacity-60" />
      </div>

      <div className="relative mx-auto flex w-full max-w-[1400px] flex-1 flex-col justify-center px-4 pb-24 pt-40 sm:px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: EASE }}
          className="flex flex-wrap items-center gap-3"
        >
          <span className="stencil rounded-full border border-gold/40 bg-gold/10 px-4 py-2 text-[10px] text-gold">
            Export Trade House
          </span>
          <span className="stencil rounded-full border border-line bg-panel/70 px-4 py-2 text-[10px] text-mist">
            New Delhi → Worldwide
          </span>
        </motion.div>

        <h1 className="font-display mt-8 text-[clamp(3rem,9vw,8.5rem)] font-black leading-[0.92] tracking-[-0.02em]">
          <motion.span
            className="text-outline block"
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.08, ease: EASE }}
          >
            INDIA TO
          </motion.span>
          <motion.span
            className="block text-bone"
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.18, ease: EASE }}
          >
            EVERY PORT
          </motion.span>
          <motion.span
            className="block"
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.28, ease: EASE }}
          >
            <span className="text-gold">ON EARTH</span>
            <span className="text-outline-gold">.</span>
          </motion.span>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.42, ease: EASE }}
          className="mt-8 max-w-xl text-[15px] leading-relaxed text-mist sm:text-base"
        >
          Hind Exim is your single Indian desk for cross-border trade — freight forwarding,
          buyer sourcing, seller sourcing and merchant exports. One call moves your cargo
          and closes your deal.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.52, ease: EASE }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <button
            onClick={() => openForm("buyer")}
            className="clip-notch group flex items-center gap-3 bg-gold px-7 py-4 text-[14px] font-bold text-ink transition-colors hover:bg-saffron"
          >
            <ArrowDownRight size={16} />
            I want to buy
          </button>
          <button
            onClick={() => openForm("seller")}
            className="clip-notch group flex items-center gap-3 border border-bone/25 bg-ink/40 px-7 py-4 text-[14px] font-bold text-bone backdrop-blur transition-colors hover:border-gold hover:text-gold"
          >
            <ArrowUpRight size={16} />
            I want to sell
          </button>
          <a
            href={SITE.phoneHref}
            className="group flex items-center gap-3 px-2 py-4 text-[14px] font-semibold text-mist transition-colors hover:text-gold"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-full border border-gold/45 bg-gold/10 text-gold">
              <Phone size={14} />
            </span>
            {SITE.phoneDisplay}
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="mt-16 grid max-w-3xl grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-4"
        >
          {[
            { k: `${liveCount}+`, v: "Live trade mandates" },
            { k: "04", v: "Core trade services" },
            { k: "18+", v: "Active trade lanes" },
            { k: "24×7", v: "Single trade desk" },
          ].map((s) => (
            <div key={s.v} className="bg-ink/80 px-5 py-5 backdrop-blur">
              <p className="font-display text-2xl font-extrabold text-gold">{s.k}</p>
              <p className="stencil mt-1.5 text-[9px] text-dim">{s.v}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";

export type AuthUser = {
  id: string;
  email: string;
  name: string;
  role: string;
};

const Ctx = createContext<{
  user: AuthUser | null;
  loading: boolean;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
}>({ user: null, loading: true, refresh: async () => {}, logout: async () => {} });

export function useAuth() {
  return useContext(Ctx);
}

function readUiCookie(): AuthUser | null {
  if (typeof document === "undefined") return null;
  const match = document.cookie.split("; ").find((c) => c.startsWith("hx_ui="));
  if (!match) return null;
  try {
    return JSON.parse(decodeURIComponent(match.slice("hx_ui=".length))) as AuthUser;
  } catch {
    return null;
  }
}

function readCache(): AuthUser | null {
  const fromCookie = readUiCookie();
  if (fromCookie) return fromCookie;
  try {
    const raw = localStorage.getItem("hx_user");
    return raw ? (JSON.parse(raw) as AuthUser) : null;
  } catch {
    return null;
  }
}

export default function AuthProvider({
  children,
  initialUser,
}: {
  children: ReactNode;
  initialUser: AuthUser | null;
}) {
  const [user, setUser] = useState<AuthUser | null>(initialUser);
  const [loading, setLoading] = useState(!initialUser);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/me", { credentials: "include", cache: "no-store" });
      const data = await res.json().catch(() => ({}));
      const next = (data.user as AuthUser | null) ?? readCache();
      setUser(next);
      if (next) localStorage.setItem("hx_user", JSON.stringify(next));
      else localStorage.removeItem("hx_user");
    } catch {
      const cached = readCache();
      if (cached) setUser(cached);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!initialUser) {
      const cached = readCache();
      if (cached) {
        setUser(cached);
        setLoading(false);
      }
    }
    refresh();
  }, [initialUser, refresh]);

  async function logout() {
    localStorage.removeItem("hx_user");
    setUser(null);
    await fetch("/api/logout", { method: "POST", credentials: "include" });
    window.location.href = "/";
  }

  return <Ctx.Provider value={{ user, loading, refresh, logout }}>{children}</Ctx.Provider>;
}

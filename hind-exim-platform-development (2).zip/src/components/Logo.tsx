const SAFFRON = "#FF9933";
const BONE = "#EDF0F3";
const GREEN = "#138808";

/**
 * Hind Exim mark — a bold up-right trade arrow built from stacked blocks
 * (saffron / bone / green), crossed by a horizontal bar with a diamond core.
 * Designed for dark backgrounds, matching the supplied brand artwork.
 */
function Mark({ size = 44 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 128 128" fill="none" aria-hidden className="shrink-0">
      <g transform="rotate(-45 64 64)">
        {/* arrowhead */}
        <rect x="26" y="18" width="72" height="22" rx="1" fill={BONE} />
        {/* shaft — left half saffron, right half bone */}
        <rect x="52" y="18" width="11" height="88" fill={SAFFRON} />
        <rect x="63" y="18" width="11" height="88" fill={BONE} />
        {/* crossbar with diamond core */}
        <rect x="28" y="57" width="70" height="11" fill={BONE} />
        <rect x="58.5" y="51.5" width="11" height="22" rx="0.5" transform="rotate(45 64 64)" fill="#05080F" />
        {/* green base blocks */}
        <rect x="48" y="98" width="30" height="8" rx="1" fill={GREEN} />
      </g>
    </svg>
  );
}

export default function Logo({
  tone = "light",
  size = 44,
  withWordmark = true,
  compact = false,
}: {
  tone?: "light" | "dark";
  size?: number;
  withWordmark?: boolean;
  compact?: boolean;
}) {
  const word = tone === "light" ? "text-bone" : "text-ink";
  const sub = tone === "light" ? "text-mist" : "text-ink/60";

  return (
    <span className="inline-flex select-none items-center gap-2.5">
      <Mark size={size} />
      {withWordmark && (
        <span className="leading-none">
          <span
            className={`font-display block font-black tracking-[0.02em] ${word} ${compact ? "text-[15px]" : "text-[19px]"}`}
            style={{ letterSpacing: "0.04em" }}
          >
            HIND
            <span style={{ color: SAFFRON }}>E</span>
            <span className={word}>X</span>
            <span style={{ color: SAFFRON }}>I</span>
            <span className={word}>M</span>
          </span>
          <span className={`stencil mt-1.5 block text-[8px] ${sub}`}>Global trade house</span>
        </span>
      )}
    </span>
  );
}

"use client";

import { useState } from "react";
import { CalendarClock, Phone, Trash2, UserRound } from "lucide-react";
import RequirementForm from "@/components/RequirementForm";
import SupplierRequestForm from "@/components/SupplierRequestForm";
import ListingCard from "@/components/ListingCard";
import { SITE, timeAgo, type ClientRequirement } from "@/lib/site";

export default function DashboardClient({
  user,
  items,
  initialKind,
}: {
  user: { name: string; email: string; role: string; lastLoginAt: string | null };
  items: ClientRequirement[];
  initialKind: "buyer" | "seller";
}) {
  const [list, setList] = useState(items);
  const [removing, setRemoving] = useState<number | null>(null);

  async function removeItem(id: number) {
    if (!confirm("Remove this listing from the board?")) return;
    setRemoving(id);
    await fetch(`/api/requirements?id=${id}`, { method: "DELETE" });
    setList((l) => l.filter((i) => i.id !== id));
    setRemoving(null);
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1.05fr_1fr]">
      <div>
        <div className="rounded-2xl border border-line bg-panel/70 p-6">
          <p className="stencil text-[10px] text-gold">Trader account</p>
          <h1 className="font-display mt-2 text-3xl font-black tracking-tight">
            {user.name.split(" ")[0]}&rsquo;s trade console
          </h1>
          <div className="mt-5 grid gap-2.5 text-[13px] text-mist sm:grid-cols-2">
            <span className="flex items-center gap-2.5 rounded-lg border border-line2 bg-abyss/60 px-3.5 py-2.5">
              <UserRound size={13} className="text-gold" />
              <span className="truncate">{user.role === "admin" ? "Admin · Hind Exim" : "Verified trader"}</span>
            </span>
            <span className="flex items-center gap-2.5 rounded-lg border border-line2 bg-abyss/60 px-3.5 py-2.5">
              <Phone size={13} className="text-gold" />
              <span className="truncate">{user.email}</span>
            </span>
            <span className="flex items-center gap-2.5 rounded-lg border border-line2 bg-abyss/60 px-3.5 py-2.5 sm:col-span-2">
              <CalendarClock size={13} className="text-gold" />
              <span>Last sign-in: {user.lastLoginAt ? timeAgo(user.lastLoginAt) : "this is your first"}</span>
            </span>
          </div>
          <a
            href={SITE.phoneHref}
            className="mt-5 flex items-center justify-between gap-3 rounded-xl border border-gold/40 bg-gold/10 px-5 py-4 transition-colors hover:bg-gold/20"
          >
            <span className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gold text-ink">
                <Phone size={15} />
              </span>
              <span>
                <span className="stencil block text-[8px] text-mist">Stuck mid-deal? Call the desk</span>
                <span className="font-display text-[15px] font-bold text-bone">{SITE.phoneDisplay}</span>
              </span>
            </span>
          </a>
        </div>

        <div className="mt-6">
          {initialKind === "seller" ? (
            <SupplierRequestForm onSubmitted={() => setList((l) => [...l])} />
          ) : (
            <RequirementForm
              initialKind={initialKind}
              onPosted={(item) => setList((l) => [item, ...l])}
            />
          )}
        </div>
      </div>

      <div>
        <div className="flex items-baseline justify-between">
          <h2 className="font-display text-xl font-extrabold">
            My listings <span className="text-gold">({list.length})</span>
          </h2>
          <p className="stencil text-[9px] text-dim">Visible on public boards</p>
        </div>
        <div className="mt-5 space-y-5">
          {list.length === 0 && (
            <div className="rounded-2xl border border-dashed border-line bg-panel/40 px-6 py-14 text-center">
              <p className="font-display text-lg font-bold text-bone">
                {initialKind === "seller" ? "No approved listings yet." : "No listings yet."}
              </p>
              <p className="mx-auto mt-2 max-w-xs text-[13px] text-mist">
                {initialKind === "seller"
                  ? "Submit a supplier request on the left — it will go live once approved by the admin desk."
                  : "Post your first requirement on the left — it goes live on the buyer board instantly."}
              </p>
            </div>
          )}
          {list.map((item) => (
            <div key={item.id} className="group/wrap relative">
              <ListingCard item={item} />
              <button
                onClick={() => removeItem(item.id)}
                disabled={removing === item.id}
                className="absolute right-3 top-12 flex items-center gap-1.5 rounded-full border border-red-500/40 bg-ink/85 px-3 py-1.5 text-[10px] text-red-300 shadow-lg backdrop-blur transition-all hover:bg-red-500/20 md:opacity-0 md:group-hover/wrap:opacity-100"
                title="Delete listing"
              >
                <Trash2 size={11} /> {removing === item.id ? "…" : "Remove"}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

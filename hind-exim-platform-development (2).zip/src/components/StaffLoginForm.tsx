"use client";

export default function StaffLoginForm() {
  return (
    <form method="POST" action="/api/login" className="space-y-4">
      <div>
        <label className="stencil mb-1.5 block text-[9px] text-dim">ID</label>
        <input name="email" required className="field" autoComplete="username" />
      </div>
      <div>
        <label className="stencil mb-1.5 block text-[9px] text-dim">Password</label>
        <input name="password" type="password" required className="field" autoComplete="current-password" />
      </div>
      <button
        type="submit"
        className="clip-notch flex w-full items-center justify-center gap-2 bg-gold px-6 py-3.5 text-[14px] font-bold text-ink hover:bg-saffron"
      >
        Continue
      </button>
    </form>
  );
}

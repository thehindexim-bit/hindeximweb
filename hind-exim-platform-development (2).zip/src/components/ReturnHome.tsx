"use client";

import Link from "next/link";
import { House } from "lucide-react";

export default function ReturnHome() {
  return (
    <Link
      href="/"
      aria-label="Return to home"
      title="Return to home"
      className="fixed right-5 top-[88px] z-[70] flex items-center gap-2 rounded-full border border-line bg-panel/90 px-3.5 py-2.5 text-[11px] font-semibold text-mist shadow-lg backdrop-blur transition-colors hover:border-gold hover:text-gold print:hidden"
    >
      <House size={13} />
      <span className="stencil hidden sm:inline">Home</span>
    </Link>
  );
}

"use client";

import Link from "next/link";
import { useState } from "react";
import { AlertCircle, ArrowRight, KeyRound, Loader2, Mail } from "lucide-react";

export default function EmailAuthForm({
  mode,
  error,
}: {
  mode: "login" | "signup";
  error?: string | null;
}) {
  const isSignup = mode === "signup";
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(error ?? null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (isSignup && password !== confirm) {
      setMsg("Passwords do not match.");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(isSignup ? "/api/signup" : "/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          password,
          confirm,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setMsg(data?.error ?? "Something went wrong.");
        setBusy(false);
        return;
      }
      if (data.user) {
        try {
          localStorage.setItem("hx_user", JSON.stringify(data.user));
        } catch {
          /* ignore */
        }
      }
      window.location.assign(isSignup ? "/?welcome=signup" : "/?welcome=1");
    } catch {
      setMsg("Network error. Try again.");
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      {msg && (
        <p className="flex items-center gap-2 rounded-lg border border-red-500/40 bg-red-500/10 px-4 py-2.5 text-[13px] text-red-300">
          <AlertCircle size={14} className="shrink-0" /> {msg}
        </p>
      )}

      {isSignup && (
        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Full name</label>
          <input
            required
            className="field"
            placeholder="Your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="name"
          />
        </div>
      )}

      <div>
        <label className="stencil mb-1.5 block text-[9px] text-dim">Email</label>
        <div className="relative">
          <Mail size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-dim" />
          <input
            type="email"
            required
            className="field pl-10"
            placeholder="you@company.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />
        </div>
      </div>

      <div>
        <label className="stencil mb-1.5 block text-[9px] text-dim">Password</label>
        <div className="relative">
          <KeyRound size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-dim" />
          <input
            type="password"
            required
            minLength={6}
            className="field pl-10"
            placeholder={isSignup ? "Minimum 6 characters" : "Your password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={isSignup ? "new-password" : "current-password"}
          />
        </div>
      </div>

      {isSignup && (
        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Confirm password</label>
          <input
            type="password"
            required
            minLength={6}
            className="field"
            placeholder="Re-enter password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            autoComplete="new-password"
          />
        </div>
      )}

      <button
        type="submit"
        disabled={busy}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-gold px-6 py-3.5 text-[14px] font-bold text-ink hover:bg-saffron disabled:opacity-60"
      >
        {busy ? <Loader2 size={15} className="animate-spin" /> : <ArrowRight size={15} />}
        {busy ? "Please wait…" : isSignup ? "Create account" : "Log in"}
      </button>
      {isSignup && (
        <p className="text-center text-[11px] leading-relaxed text-dim">
          By creating an account you agree to our{" "}
          <Link href="/privacy" className="text-gold hover:underline">
            Privacy Policy
          </Link>
          , including that Hind Exim is not liable for third-party fraud.
        </p>
      )}

      <p className="text-center text-[13px] text-mist">
        {isSignup ? (
          <>
            Already have an account?{" "}
            <Link href="/login" className="font-semibold text-gold hover:text-saffron">
              Log in
            </Link>
          </>
        ) : (
          <>
            New here?{" "}
            <Link href="/signup" className="font-semibold text-gold hover:text-saffron">
              Create an account
            </Link>
          </>
        )}
      </p>
    </form>
  );
}

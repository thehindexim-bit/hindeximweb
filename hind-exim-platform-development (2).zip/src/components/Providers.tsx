"use client";

import type { ReactNode } from "react";
import AuthProvider, { type AuthUser } from "@/components/AuthProvider";

export default function Providers({
  children,
  user,
}: {
  children: ReactNode;
  user: AuthUser | null;
}) {
  return <AuthProvider initialUser={user}>{children}</AuthProvider>;
}

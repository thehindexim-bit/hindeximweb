"use client";

import { useMemo, useState } from "react";
import { Plus, Search } from "lucide-react";
import ListingCard from "@/components/ListingCard";
import type { ClientRequirement } from "@/lib/site";
import { useAuth } from "@/components/AuthProvider";
import { useTradeForm } from "@/components/TradeFormProvider";

export default function BoardClient({
  items,
  kind,
}: {
  items: ClientRequirement[];
  kind: "buyer" | "seller";
  signedIn?: boolean;
}) {
  const { user } = useAuth();
  const { openForm } = useTradeForm();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const cats = useMemo(() => ["All", ...Array.from(new Set(items.map((i) => i.category)))], [items]);
  const isBuyer = kind === "buyer";

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return items.filter((i) => {
      if (cat !== "All" && i.category !== cat) return false;
      if (!query) return true;
      return [i.title, i.description, i.hsCode, i.originCountry, i.destinationCountry, i.company, i.contactName]
        .filter(Boolean)
        .join(" ")
        .toLowerCase()
        .includes(query);
    });
  }, [items, q, cat]);

  return (
    <div>
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="relative w-full max-w-md">
          <Search size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-dim" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={isBuyer ? "Search products, HS codes, destinations…" : "Search supplies, origins, quantities…"}
            className="field pl-10"
          />
        </div>
        <button
          onClick={() => openForm(kind)}
          className="clip-notch inline-flex w-fit items-center gap-2 bg-gold px-5 py-3 text-[13px] font-bold text-ink transition-colors hover:bg-saffron"
        >
          <Plus size={15} />
          {isBuyer ? "Post a buy requirement" : "List your supply"}
        </button>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {cats.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`stencil rounded-full border px-4 py-2 text-[9px] transition-colors ${
              cat === c ? "border-gold/60 bg-gold/15 text-gold" : "border-line bg-panel/50 text-mist hover:text-bone"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="mt-14 rounded-2xl border border-dashed border-line bg-panel/40 px-8 py-16 text-center">
          <p className="font-display text-xl font-bold text-bone">Nothing on this lane yet.</p>
          <p className="mx-auto mt-2 max-w-sm text-[13px] text-mist">
            {user ? "Be the first to post — tap the button above." : "Log in to post the first listing."}
          </p>
        </div>
      ) : (
        <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((item) => (
            <ListingCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}

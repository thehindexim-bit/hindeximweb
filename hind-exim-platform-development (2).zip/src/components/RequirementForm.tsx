"use client";

import { useState } from "react";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import type { ClientRequirement } from "@/lib/site";

const CATEGORIES = [
  "Agriculture & Food",
  "Spices",
  "Textiles & Apparel",
  "Pharmaceuticals",
  "Metals & Scrap",
  "Chemicals",
  "Handicrafts",
  "Engineering Goods",
  "Consumer Goods",
  "General",
];

const UNITS = ["MT", "KG", "CBM", "20FT FCL", "40FT FCL", "PCS", "CARTONS"];

const empty = {
  title: "",
  category: "General",
  hsCode: "",
  quantity: "",
  unit: "MT",
  originCountry: "",
  destinationCountry: "",
  priceRange: "",
  description: "",
  company: "",
  contactName: "",
};

export default function RequirementForm({
  initialKind = "buyer",
  endpoint = "/api/requirements",
  onPosted,
}: {
  initialKind?: "buyer" | "seller";
  endpoint?: "/api/requirements" | "/api/admin/requirements";
  onPosted?: (item: ClientRequirement) => void;
}) {
  const [kind, setKind] = useState<"buyer" | "seller">(initialKind);
  const [form, setForm] = useState(empty);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const set = (k: keyof typeof empty) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setDone(false);
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, ...form }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data?.error ?? "Could not post. Try again.");
        return;
      }
      setForm(empty);
      setDone(true);
      onPosted?.(data.item);
      setTimeout(() => setDone(false), 4000);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-line bg-panel/70 p-6">
      <div className="grid grid-cols-2 gap-2 rounded-full border border-line bg-abyss/60 p-1.5">
        {(["buyer", "seller"] as const).map((k) => (
          <button
            type="button"
            key={k}
            onClick={() => setKind(k)}
            className={`stencil rounded-full px-4 py-2.5 text-[10px] transition-all ${
              kind === k ? "bg-gold text-ink" : "text-mist hover:text-bone"
            }`}
          >
            {k === "buyer" ? "I want to buy" : "I want to sell"}
          </button>
        ))}
      </div>

      <div className="mt-5 space-y-3.5">
        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Product / commodity *</label>
          <input className="field" required placeholder="e.g. Basmati Rice 1121 Steam" value={form.title} onChange={set("title")} />
        </div>
        <div className="grid gap-3.5 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Category</label>
            <select className="field" value={form.category} onChange={set("category")}>
              {CATEGORIES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">HS code</label>
            <input className="field" placeholder="e.g. 1006.30" value={form.hsCode} onChange={set("hsCode")} />
          </div>
        </div>
        <div className="grid gap-3.5 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Quantity</label>
            <input className="field" placeholder="e.g. 500" value={form.quantity} onChange={set("quantity")} />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Unit</label>
            <select className="field" value={form.unit} onChange={set("unit")}>
              {UNITS.map((u) => (
                <option key={u}>{u}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="grid gap-3.5 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Origin country</label>
            <input className="field" placeholder="e.g. India" value={form.originCountry} onChange={set("originCountry")} />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Destination country</label>
            <input className="field" placeholder="e.g. UAE" value={form.destinationCountry} onChange={set("destinationCountry")} />
          </div>
        </div>
        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Target price / terms</label>
          <input className="field" placeholder="e.g. FOB $850/MT · LC at sight" value={form.priceRange} onChange={set("priceRange")} />
        </div>
        <div className="grid gap-3.5 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Company</label>
            <input className="field" placeholder="e.g. Al Noor Trading LLC" value={form.company} onChange={set("company")} />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Contact person</label>
            <input className="field" placeholder="e.g. Mr. Kapoor" value={form.contactName} onChange={set("contactName")} />
          </div>
        </div>
        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Details</label>
          <textarea
            className="field min-h-[88px] resize-y"
            placeholder="Specs, packaging, certifications, timeline…"
            value={form.description}
            onChange={set("description")}
          />
        </div>
      </div>

      {error && <p className="mt-4 rounded-lg border border-red-500/40 bg-red-500/10 px-4 py-2.5 text-[13px] text-red-300">{error}</p>}
      {done && (
        <p className="mt-4 flex items-center gap-2 rounded-lg border border-leaf/40 bg-leaf/10 px-4 py-2.5 text-[13px] text-leaf">
          <CheckCircle2 size={15} /> Posted to the {kind === "buyer" ? "buyer" : "seller"} board.
        </p>
      )}

      <button
        type="submit"
        disabled={busy}
        className="clip-notch mt-6 inline-flex w-full items-center justify-center gap-2 bg-gold px-6 py-3.5 text-[14px] font-bold text-ink transition-colors hover:bg-saffron disabled:opacity-60"
      >
        {busy ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
        Post {kind === "buyer" ? "buy requirement" : "supply listing"}
      </button>
    </form>
  );
}

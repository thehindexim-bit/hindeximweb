"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Activity,
  ArrowLeftRight,
  CheckCircle2,
  Loader2,
  RefreshCw,
  ShieldCheck,
  Trash2,
  TrendingUp,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import RequirementForm from "@/components/RequirementForm";
import { SITE, timeAgo, type ClientLoginEvent, type ClientRequirement, type ClientUser } from "@/lib/site";

type Tab = "overview" | "users" | "requirements" | "supplier-requests" | "logins";

const TABS: { id: Tab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "users", label: "Users" },
  { id: "requirements", label: "Requirements" },
  { id: "supplier-requests", label: "Supplier Requests" },
  { id: "logins", label: "Login info" },
];

export default function AdminClient({ adminPhone }: { adminPhone: string }) {
  const [tab, setTab] = useState<Tab>("overview");
  const [users, setUsers] = useState<ClientUser[] | null>(null);
  const [buyers, setBuyers] = useState<ClientRequirement[] | null>(null);
  const [sellers, setSellers] = useState<ClientRequirement[] | null>(null);
  const [supplierRequests, setSupplierRequests] = useState<any[] | null>(null);
  const [logins, setLogins] = useState<ClientLoginEvent[] | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const [u, b, s, sr, l] = await Promise.all([
        fetch("/api/admin/users").then((r) => (r.ok ? r.json() : { items: [] })),
        fetch("/api/requirements?kind=buyer").then((r) => (r.ok ? r.json() : { items: [] })),
        fetch("/api/requirements?kind=seller").then((r) => (r.ok ? r.json() : { items: [] })),
        fetch("/api/admin/supplier-requests").then((r) => (r.ok ? r.json() : { items: [] })),
        fetch("/api/admin/logins").then((r) => (r.ok ? r.json() : { items: [] })),
      ]);
      setUsers(u.items ?? []);
      setBuyers(b.items ?? []);
      setSellers(s.items ?? []);
      setSupplierRequests(sr.items ?? []);
      setLogins(l.items ?? []);
    } catch {
      setUsers([]);
      setBuyers([]);
      setSellers([]);
      setSupplierRequests([]);
      setLogins([]);
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="stencil flex items-center gap-2 text-[10px] text-gold">
            <ShieldCheck size={13} /> Control room · {adminPhone}
          </p>
          <h1 className="font-display mt-2 text-3xl font-black tracking-tight sm:text-4xl">Admin panel</h1>
        </div>
        <button
          onClick={load}
          className="flex items-center gap-2 rounded-full border border-line bg-panel px-4 py-2.5 text-[12px] text-mist transition-colors hover:border-gold/50 hover:text-gold"
        >
          {busy ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
          Refresh
        </button>
      </div>

      <div className="mt-8 flex flex-wrap gap-2 border-b border-line pb-px">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`stencil rounded-t-xl border-b-2 px-5 py-3 text-[10px] transition-colors ${
              tab === t.id ? "border-gold bg-panel text-gold" : "border-transparent text-mist hover:text-bone"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-8">
        {tab === "overview" && (
          <Overview users={users} buyers={buyers} sellers={sellers} logins={logins} />
        )}
        {tab === "users" && <UsersPanel users={users} reload={load} />}
        {tab === "requirements" && (
          <RequirementsPanel buyers={buyers} sellers={sellers} reload={load} />
        )}
        {tab === "supplier-requests" && (
          <SupplierRequestsPanel supplierRequests={supplierRequests} reload={load} />
        )}
        {tab === "logins" && <LoginsPanel logins={logins} />}
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-2xl border border-line bg-panel/70 p-5">
      <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${accent ? "bg-gold/15 text-gold" : "bg-bone/[0.06] text-mist"}`}>
        {icon}
      </div>
      <p className="font-display mt-4 text-3xl font-extrabold text-bone">{value}</p>
      <p className="stencil mt-1 text-[9px] text-dim">{label}</p>
    </div>
  );
}

function Overview({
  users,
  buyers,
  sellers,
  logins,
}: {
  users: ClientUser[] | null;
  buyers: ClientRequirement[] | null;
  sellers: ClientRequirement[] | null;
  logins: ClientLoginEvent[] | null;
}) {
  if (!users || !buyers || !sellers || !logins) return <Loading />;
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<Users size={16} />} label="Registered users" value={String(users.length)} />
        <StatCard icon={<TrendingUp size={16} />} label="Buy requirements" value={String(buyers.length)} accent />
        <StatCard icon={<ArrowLeftRight size={16} />} label="Seller listings" value={String(sellers.length)} accent />
        <StatCard icon={<Activity size={16} />} label="Total sign-ins" value={String(logins.length)} />
      </div>
      <OtpOutbox />

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-line bg-panel/70 p-6">
          <p className="stencil text-[10px] text-dim">Newest users</p>
          <ul className="mt-4 divide-y divide-line2">
            {users.slice(0, 5).map((u) => (
              <li key={u.id} className="flex items-center justify-between gap-3 py-3 text-[13px]">
                <span className="min-w-0">
                  <span className="block truncate font-medium text-bone">{u.name}</span>
                  <span className="block truncate text-[12px] text-dim">{u.phone ?? u.email}</span>
                </span>
                <span className={`stencil shrink-0 rounded-full border px-2.5 py-1 text-[8px] ${u.role === "admin" ? "border-gold/50 bg-gold/10 text-gold" : "border-line text-dim"}`}>
                  {u.role}
                </span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-2xl border border-line bg-panel/70 p-6">
          <p className="stencil text-[10px] text-dim">Recent sign-ins</p>
          <ul className="mt-4 divide-y divide-line2">
            {logins.slice(0, 5).map((l) => (
              <li key={l.id} className="flex items-center justify-between gap-3 py-3 text-[13px]">
                <span className="truncate text-bone">{l.email ?? l.phone}</span>
                <span className="flex shrink-0 items-center gap-2 text-[12px] text-dim">
                  <ProviderBadge provider={l.provider} />
                  {timeAgo(l.createdAt)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

function ProviderBadge({ provider }: { provider: string }) {
  const isGoogle = provider === "whatsapp";
  return (
    <span className={`stencil rounded-full border px-2.5 py-1 text-[8px] ${isGoogle ? "border-saffron/50 text-saffron" : "border-line text-dim"}`}>
      {isGoogle ? "WhatsApp" : "Password"}
    </span>
  );
}

function Loading() {
  return (
    <div className="flex items-center gap-3 py-16 text-mist">
      <Loader2 size={16} className="animate-spin text-gold" /> Loading…
    </div>
  );
}

function UsersPanel({ users, reload }: { users: ClientUser[] | null; reload: () => void }) {
  const [form, setForm] = useState({ name: "", phone: "", email: "", password: "", role: "user" });
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const res = await fetch("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setMsg({ ok: false, text: data?.error ?? "Failed to add user." });
      return;
    }
    setForm({ name: "", phone: "", email: "", password: "", role: "user" });
    setMsg({ ok: true, text: `Added ${data.item.phone} as ${data.item.role}.` });
    reload();
  }

  async function remove(id: number, phone: string) {
    if (!confirm(`Delete ${phone}? This cannot be undone.`)) return;
    const res = await fetch(`/api/admin/users?id=${id}`, { method: "DELETE" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setMsg({ ok: false, text: data?.error ?? "Delete failed." });
      return;
    }
    setMsg({ ok: true, text: `Deleted ${phone}.` });
    reload();
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
      <div className="overflow-x-auto rounded-2xl border border-line bg-panel/70">
        {!users ? (
          <Loading />
        ) : (
          <table className="w-full min-w-[680px] text-left text-[13px]">
            <thead>
              <tr className="stencil border-b border-line text-[9px] text-dim">
                <th className="px-5 py-4 font-medium">User</th>
                <th className="px-5 py-4 font-medium">Role</th>
                <th className="px-5 py-4 font-medium">Via</th>
                <th className="px-5 py-4 font-medium">Last sign-in</th>
                <th className="px-5 py-4 font-medium">Joined</th>
                <th className="px-5 py-4" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line2">
              {users.map((u) => (
                <tr key={u.id} className="transition-colors hover:bg-bone/[0.02]">
                  <td className="px-5 py-3.5">
                    <span className="block font-medium text-bone">{u.name}</span>
                    <span className="block text-[12px] text-dim">{u.phone ?? u.email}</span>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className={`stencil rounded-full border px-2.5 py-1 text-[8px] ${u.role === "admin" ? "border-gold/50 bg-gold/10 text-gold" : "border-line text-dim"}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-5 py-3.5"><ProviderBadge provider={u.provider} /></td>
                  <td className="px-5 py-3.5 text-mist">{u.lastLoginAt ? timeAgo(u.lastLoginAt) : "Never"}</td>
                  <td className="px-5 py-3.5 text-mist">{timeAgo(u.createdAt)}</td>
                  <td className="px-5 py-3.5 text-right">
                    <button
                      onClick={() => remove(u.id, u.phone ?? u.email ?? "")}
                      className="rounded-lg border border-red-500/40 p-2 text-red-300 transition-colors hover:bg-red-500/15"
                      title={`Delete ${u.phone ?? u.email}`}
                    >
                      <Trash2 size={13} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <form onSubmit={add} className="h-fit rounded-2xl border border-line bg-panel/70 p-6">
        <p className="stencil flex items-center gap-2 text-[10px] text-gold">
          <UserPlus size={13} /> Add user
        </p>
        <div className="mt-4 space-y-3">
          <input className="field" placeholder="Full name" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          <input className="field" type="email" placeholder="Email" required value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
          <input className="field" type="text" placeholder="Temporary password (6+ chars)" required minLength={6} value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
          <select className="field" value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))}>
            <option value="user">Trader (standard)</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        {msg && (
          <p className={`mt-3 rounded-lg border px-4 py-2.5 text-[12px] ${msg.ok ? "border-leaf/40 bg-leaf/10 text-leaf" : "border-red-500/40 bg-red-500/10 text-red-300"}`}>
            {msg.text}
          </p>
        )}
        <button disabled={busy} className="clip-notch mt-4 flex w-full items-center justify-center gap-2 bg-gold px-5 py-3 text-[13px] font-bold text-ink hover:bg-saffron disabled:opacity-60">
          {busy ? <Loader2 size={14} className="animate-spin" /> : <UserPlus size={14} />}
          Create account
        </button>
      </form>
    </div>
  );
}

function RequirementsPanel({
  buyers,
  sellers,
  reload,
}: {
  buyers: ClientRequirement[] | null;
  sellers: ClientRequirement[] | null;
  reload: () => void;
}) {
  const [filter, setFilter] = useState<"all" | "buyer" | "seller">("all");
  const [deleting, setDeleting] = useState<number | null>(null);

  const all = [...(buyers ?? []), ...(sellers ?? [])]
    .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
    .filter((i) => filter === "all" || i.kind === filter);

  async function remove(id: number) {
    if (!confirm("Delete this listing?")) return;
    setDeleting(id);
    await fetch(`/api/admin/requirements?id=${id}`, { method: "DELETE" });
    setDeleting(null);
    reload();
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[1fr_1.6fr]">
      <div>
        <p className="stencil mb-3 text-[10px] text-dim">Post buyer / seller requirement on behalf of a client</p>
        <RequirementForm endpoint="/api/admin/requirements" onPosted={() => reload()} />
      </div>
      <div className="overflow-x-auto rounded-2xl border border-line bg-panel/70">
        <div className="flex gap-2 border-b border-line px-5 py-4">
          {(["all", "buyer", "seller"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`stencil rounded-full border px-4 py-1.5 text-[9px] transition-colors ${
                filter === f ? "border-gold/60 bg-gold/15 text-gold" : "border-line text-mist hover:text-bone"
              }`}
            >
              {f === "all" ? "All" : f === "buyer" ? "Buyers" : "Sellers"}
            </button>
          ))}
        </div>
        {!buyers || !sellers ? (
          <Loading />
        ) : (
          <table className="w-full min-w-[640px] text-left text-[13px]">
            <thead>
              <tr className="stencil border-b border-line text-[9px] text-dim">
                <th className="px-5 py-4 font-medium">Listing</th>
                <th className="px-5 py-4 font-medium">Type</th>
                <th className="px-5 py-4 font-medium">Company</th>
                <th className="px-5 py-4 font-medium">Posted</th>
                <th className="px-5 py-4" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line2">
              {all.map((i) => (
                <tr key={i.id} className="transition-colors hover:bg-bone/[0.02]">
                  <td className="max-w-[260px] px-5 py-3.5">
                    <span className="block truncate font-medium text-bone">{i.title}</span>
                    <span className="block truncate text-[12px] text-dim">
                      {i.category}
                      {i.hsCode ? ` · HS ${i.hsCode}` : ""}
                      {i.quantity ? ` · ${i.quantity} ${i.unit ?? ""}` : ""}
                    </span>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className={`stencil rounded-full border px-2.5 py-1 text-[8px] ${i.kind === "buyer" ? "border-gold/50 bg-gold/10 text-gold" : "border-leaf/50 bg-leaf/10 text-leaf"}`}>
                      {i.kind}
                    </span>
                  </td>
                  <td className="max-w-[160px] truncate px-5 py-3.5 text-mist">{i.company ?? i.postedByName ?? "—"}</td>
                  <td className="px-5 py-3.5 text-mist">{timeAgo(i.createdAt)}</td>
                  <td className="px-5 py-3.5 text-right">
                    <button
                      onClick={() => remove(i.id)}
                      disabled={deleting === i.id}
                      className="rounded-lg border border-red-500/40 p-2 text-red-300 transition-colors hover:bg-red-500/15 disabled:opacity-50"
                      title="Delete listing"
                    >
                      {deleting === i.id ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
                    </button>
                  </td>
                </tr>
              ))}
              {all.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-10 text-center text-mist">
                    No listings yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function LoginsPanel({ logins }: { logins: ClientLoginEvent[] | null }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-line bg-panel/70">
      {!logins ? (
        <Loading />
      ) : (
        <table className="w-full min-w-[560px] text-left text-[13px]">
          <thead>
            <tr className="stencil border-b border-line text-[9px] text-dim">
              <th className="px-5 py-4 font-medium">#</th>
              <th className="px-5 py-4 font-medium">Phone</th>
              <th className="px-5 py-4 font-medium">Via</th>
              <th className="px-5 py-4 font-medium">When</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line2">
            {logins.map((l) => (
              <tr key={l.id} className="transition-colors hover:bg-bone/[0.02]">
                <td className="px-5 py-3.5 text-dim">{l.id}</td>
                <td className="px-5 py-3.5 font-medium text-bone">{l.email ?? l.phone}</td>
                <td className="px-5 py-3.5"><ProviderBadge provider={l.provider} /></td>
                <td className="px-5 py-3.5 text-mist">
                  {new Date(l.createdAt).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}
                  <span className="ml-2 text-[11px] text-dim">({timeAgo(l.createdAt)})</span>
                </td>
              </tr>
            ))}
            {logins.length === 0 && (
              <tr>
                <td colSpan={4} className="px-5 py-10 text-center text-mist">
                  No sign-ins recorded yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}

function SupplierRequestsPanel({
  supplierRequests,
  reload,
}: {
  supplierRequests: any[] | null;
  reload: () => void;
}) {
  const [busyIds, setBusyIds] = useState<number[]>([]);

  async function approve(id: number) {
    setBusyIds((prev) => [...prev, id]);
    const res = await fetch(`/api/admin/supplier-requests/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "approved" }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      alert(data?.error ?? "Approval failed.");
    } else {
      reload();
    }
    setBusyIds((prev) => prev.filter((x) => x !== id));
  }

  async function reject(id: number) {
    setBusyIds((prev) => [...prev, id]);
    const res = await fetch(`/api/admin/supplier-requests/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "rejected" }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      alert(data?.error ?? "Rejection failed.");
    } else {
      reload();
    }
    setBusyIds((prev) => prev.filter((x) => x !== id));
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
      <div className="overflow-x-auto rounded-2xl border border-line bg-panel/70">
        {!supplierRequests ? (
          <Loading />
        ) : (
          <table className="w-full min-w-[700px] text-left text-[13px]">
            <thead>
              <tr className="stencil border-b border-line text-[9px] text-dim">
                <th className="px-5 py-4 font-medium">Company</th>
                <th className="px-5 py-4 font-medium">Contact</th>
                <th className="px-5 py-4 font-medium">Phone</th>
                <th className="px-5 py-4 font-medium">Sector</th>
                <th className="px-5 py-4 font-medium">Status</th>
                <th className="px-5 py-4 font-medium">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line2">
              {supplierRequests.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-mist">
                    No supplier requests yet.
                  </td>
                </tr>
              ) : (
                supplierRequests.map((r: any) => (
                  <tr
                    key={r.id}
                    className="transition-colors hover:bg-bone/[0.02]"
                  >
                    <td className="max-w-[180px] px-5 py-3.5">
                      <span className="block truncate font-medium text-bone">{r.companyName}</span>
                      <span className="block truncate text-[12px] text-dim">{r.commodity}</span>
                    </td>
                    <td className="max-w-[120px] truncate px-5 py-3.5 text-bone">{r.contactName}</td>
                    <td className="max-w-[140px] truncate px-5 py-3.5 text-mist">{r.email ?? r.phone}</td>
                    <td className="max-w-[120px] px-5 py-3.5 text-[12px] text-dim">{r.sector}</td>
                    <td className="px-5 py-3.5">
                      <span
                        className={`stencil shrink-0 rounded-full border px-2.5 py-1 text-[8px] ${
                          r.status === "pending"
                            ? "border-gold/50 bg-gold/10 text-gold"
                            : r.status === "approved"
                            ? "border-leaf/50 bg-leaf/10 text-leaf"
                            : "border-red-500/50 bg-red-500/10 text-red-300"
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      {r.status === "pending" && (
                        <div className="flex gap-2 justify-end">
                          <button
                            onClick={() => approve(r.id)}
                            disabled={busyIds.includes(r.id)}
                            className="flex items-center gap-1.5 rounded-lg border border-leaf/40 px-3 py-1.5 text-[10px] text-leaf transition-colors hover:bg-leaf/20 disabled:opacity-50"
                          >
                            {busyIds.includes(r.id) ? <Loader2 size={12} className="animate-spin" /> : <CheckCircle2 size={12} />}
                            Approve
                          </button>
                          <button
                            onClick={() => reject(r.id)}
                            disabled={busyIds.includes(r.id)}
                            className="flex items-center gap-1.5 rounded-lg border border-red-500/40 px-3 py-1.5 text-[10px] text-red-300 transition-colors hover:bg-red-500/20 disabled:opacity-50"
                          >
                            {busyIds.includes(r.id) ? <Loader2 size={12} className="animate-spin" /> : <X size={12} />}
                            Reject
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>

      <div className="h-fit rounded-2xl border border-line bg-panel/70 p-6">
        <p className="stencil mb-4 text-[10px] text-dim">Supplier Request Details</p>
        <p className="text-[12px] text-mist mb-2">
          Pending requests appear below. Approving a supplier request creates a live seller listing on the public seller board.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1 block text-[9px] text-dim">Pending Requests</label>
            <p className="font-display text-lg font-bold text-bone">
              {supplierRequests?.filter((r: any) => r.status === "pending").length ?? 0}
            </p>
          </div>
          <div>
            <label className="stencil mb-1 block text-[9px] text-dim">Approved Listings</label>
            <p className="font-display text-lg font-bold text-bone">
              {supplierRequests?.filter((r: any) => r.status === "approved").length ?? 0}
            </p>
          </div>
          <div>
            <label className="stencil mb-1 block text-[9px] text-dim">Rejected Requests</label>
            <p className="font-display text-lg font-bold text-bone">
              {supplierRequests?.filter((r: any) => r.status === "rejected").length ?? 0}
            </p>
          </div>
          <div>
            <label className="stencil mb-1 block text-[9px] text-dim">Total Submitted</label>
            <p className="font-display text-lg font-bold text-bone">{supplierRequests?.length ?? 0}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function OtpOutbox() {
  const [items, setItems] = useState<{ id: number; phone: string; code: string; waUrl: string | null }[]>([]);
  useEffect(() => {
    fetch("/api/admin/otps")
      .then((r) => (r.ok ? r.json() : { items: [] }))
      .then((d) => setItems(d.items ?? []))
      .catch(() => setItems([]));
  }, []);
  if (items.length === 0) return null;
  return (
    <div className="rounded-2xl border border-gold/30 bg-panel/70 p-6">
      <p className="stencil text-[10px] text-gold">WhatsApp OTP queue — tap Send from your phone ({SITE.phoneDisplay})</p>
      <ul className="mt-4 divide-y divide-line2">
        {items.slice(0, 8).map((i) => (
          <li key={i.id} className="flex items-center justify-between gap-3 py-3 text-[13px]">
            <span>
              <span className="block font-medium text-bone">{i.phone}</span>
              <span className="font-mono text-gold tracking-widest">{i.code}</span>
            </span>
            {i.waUrl && (
              <a
                href={i.waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="clip-notch bg-leaf px-3 py-2 text-[11px] font-bold text-ink"
              >
                Send on WhatsApp
              </a>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

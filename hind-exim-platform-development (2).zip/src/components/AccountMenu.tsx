"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { ChevronDown, LayoutDashboard, LogOut, ShieldCheck, UserRound } from "lucide-react";
import type { AuthUser } from "@/components/AuthProvider";

export default function AccountMenu({ user, logout }: { user: AuthUser; logout: () => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="clip-notch flex items-center gap-2 bg-gold px-4 py-2.5 text-[13px] font-semibold text-ink hover:bg-saffron"
      >
        <UserRound size={14} />
        My account
        <ChevronDown size={14} className={open ? "rotate-180 transition" : "transition"} />
      </button>
      {open && (
        <div className="absolute left-0 top-[calc(100%+8px)] z-[90] w-[280px] overflow-hidden rounded-2xl border border-line bg-panel shadow-[0_24px_60px_-24px_rgba(0,0,0,0.8)]">
          <div className="border-b border-line px-4 py-4">
            <p className="stencil text-[8px] text-gold">Signed in</p>
            <p className="mt-1 truncate text-[15px] font-bold text-bone">{user.name}</p>
            <p className="truncate text-[12px] text-mist">{user.email}</p>
          </div>
          <div className="p-2">
            <Link
              href="/dashboard"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-[13px] text-bone hover:bg-bone/[0.06]"
            >
              <LayoutDashboard size={14} className="text-gold" /> Trade console
            </Link>
            {user.role === "admin" && (
              <Link
                href="/admin"
                onClick={() => setOpen(false)}
                className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-[13px] text-gold hover:bg-gold/10"
              >
                <ShieldCheck size={14} /> Admin panel
              </Link>
            )}
            <button
              onClick={() => logout()}
              className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-[13px] text-mist hover:bg-bone/[0.06]"
            >
              <LogOut size={14} /> Sign out
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

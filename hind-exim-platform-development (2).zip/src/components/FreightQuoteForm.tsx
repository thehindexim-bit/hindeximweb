"use client";

import { useState } from "react";
import { useAuth } from "@/components/AuthProvider";
import { useRouter } from "next/navigation";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { SITE } from "@/lib/site";

export default function FreightQuoteForm() {
  const { user } = useAuth();
  const router = useRouter();
  const [cargoType, setCargoType] = useState<"fcl" | "lcl" | "air">("fcl");
  const [form, setForm] = useState({
    origin: "Mundra Port (INMUN)",
    destination: "Jebel Ali (AEJEA)",
    commodity: "",
    weightVolume: "",
    containerSize: "20 FT Standard",
    readinessDate: "",
    company: "",
    contactName: "",
    contactPhone: "",
    notes: "",
  });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const msg = [
      "*HIND EXIM — Freight Quote*",
      `*Mode:* ${cargoType.toUpperCase()}`,
      `*Origin:* ${form.origin}`,
      `*Destination:* ${form.destination}`,
      `*Commodity:* ${form.commodity}`,
      cargoType === "fcl" ? `*Container:* ${form.containerSize}` : `*Weight/Volume:* ${form.weightVolume}`,
      form.readinessDate ? `*Ready:* ${form.readinessDate}` : null,
      form.company ? `*Company:* ${form.company}` : null,
      `*Contact:* ${form.contactName || user?.name || "—"}`,
      `*Phone:* ${form.contactPhone || "—"}`,
      user?.email ? `*Email:* ${user.email}` : null,
      form.notes ? `*Notes:* ${form.notes}` : null,
    ]
      .filter(Boolean)
      .join("\n");
    window.open(`${SITE.whatsapp}?text=${encodeURIComponent(msg)}`, "_blank", "noopener,noreferrer");
    setDone(true);
    setBusy(false);
  }

  return (
    <form onSubmit={submit} className="rounded-2xl border border-line bg-panel/85 p-6 shadow-xl backdrop-blur-md sm:p-8">
      <div className="flex items-center justify-between">
        <span className="stencil text-[10px] text-gold">Instant Freight Rate Desk</span>
        <span className="stencil rounded-full border border-gold/40 bg-gold/10 px-3 py-1 text-[9px] text-gold">
          24h Turnaround
        </span>
      </div>

      <div className="mt-5 grid grid-cols-3 gap-2 rounded-full border border-line bg-abyss/60 p-1.5">
        {[
          { id: "fcl", label: "FCL Ocean" },
          { id: "lcl", label: "LCL Cargo" },
          { id: "air", label: "Air Freight" },
        ].map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => setCargoType(m.id as "fcl" | "lcl" | "air")}
            className={`stencil rounded-full py-2 text-[10px] transition-all ${
              cargoType === m.id ? "bg-gold font-bold text-ink" : "text-mist hover:text-bone"
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      <div className="mt-5 space-y-3.5">
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Origin Port / ICD *</label>
            <input
              required
              className="field"
              value={form.origin}
              onChange={(e) => setForm({ ...form, origin: e.target.value })}
              placeholder="e.g. Nhava Sheva (INNSA) or ICD Jaipur"
            />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Destination Port *</label>
            <input
              required
              className="field"
              value={form.destination}
              onChange={(e) => setForm({ ...form, destination: e.target.value })}
              placeholder="e.g. Jebel Ali / Rotterdam / New York"
            />
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Commodity & HS Code *</label>
            <input
              required
              className="field"
              value={form.commodity}
              onChange={(e) => setForm({ ...form, commodity: e.target.value })}
              placeholder="e.g. Basmati Rice (HS 1006.30)"
            />
          </div>
          {cargoType === "fcl" ? (
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">Container Type</label>
              <select
                className="field"
                value={form.containerSize}
                onChange={(e) => setForm({ ...form, containerSize: e.target.value })}
              >
                <option>20 FT Standard (28-30 MT max)</option>
                <option>40 FT Standard (FCL)</option>
                <option>40 FT High Cube (HQ)</option>
                <option>20/40 FT Reefer (Refrigerated)</option>
                <option>Open Top / Flat Rack (Project Cargo)</option>
              </select>
            </div>
          ) : (
            <div>
              <label className="stencil mb-1.5 block text-[9px] text-dim">Weight & Volume *</label>
              <input
                required
                className="field"
                value={form.weightVolume}
                onChange={(e) => setForm({ ...form, weightVolume: e.target.value })}
                placeholder="e.g. 3,500 KG / 8.5 CBM"
              />
            </div>
          )}
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Target Readiness</label>
            <input
              type="date"
              className="field"
              value={form.readinessDate}
              onChange={(e) => setForm({ ...form, readinessDate: e.target.value })}
            />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Company Name</label>
            <input
              className="field"
              value={form.company}
              onChange={(e) => setForm({ ...form, company: e.target.value })}
              placeholder="e.g. Global Foods Ltd"
            />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Contact Person</label>
            <input
              className="field"
              value={form.contactName}
              onChange={(e) => setForm({ ...form, contactName: e.target.value })}
              placeholder="e.g. Mr. Sharma"
            />
          </div>
        </div>

        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Phone / WhatsApp *</label>
          <input
            required
            className="field"
            value={form.contactPhone}
            onChange={(e) => setForm({ ...form, contactPhone: e.target.value })}
            placeholder="98765 43210"
          />
        </div>
        {!user && (
          <p className="rounded-lg border border-gold/40 bg-gold/10 px-4 py-2.5 text-[12px] text-gold">
            You must log in / sign up with your phone number before submitting a freight quote.
          </p>
        )}

        <div>
          <label className="stencil mb-1.5 block text-[9px] text-dim">Special Instructions / Cargo Notes</label>
          <textarea
            className="field min-h-[60px] resize-y"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            placeholder="DG Cargo, temperature control, factory stuffing needed, customs CHA needed..."
          />
        </div>
      </div>

      {done && (
        <div className="mt-4 flex items-center gap-3 rounded-lg border border-leaf/40 bg-leaf/10 p-4 text-[13px] text-leaf">
          <CheckCircle2 size={18} className="shrink-0" />
          <div>
            <p className="font-bold">Freight quote request submitted.</p>
            <p className="text-leaf/80">
              Our shipping desk is calculating slot rates. For emergency vessel cutoffs, call{" "}
              <a href={SITE.phoneHref} className="underline font-semibold">
                {SITE.phoneDisplay}
              </a>
              .
            </p>
          </div>
        </div>
      )}

      <button
        type="submit"
        disabled={busy}
        className="clip-notch mt-5 flex w-full items-center justify-center gap-2 bg-gold px-6 py-3.5 text-[14px] font-bold text-ink transition-colors hover:bg-saffron disabled:opacity-60"
      >
        {busy ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
        Request competitive freight rate
      </button>

      <p className="stencil mt-3 text-center text-[8px] text-dim">
        Prefer immediate booking? Call desk: {SITE.phoneDisplay} · 24×7
      </p>
    </form>
  );
}

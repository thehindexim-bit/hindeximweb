"use client";

import type { ReactNode } from "react";
import { useTradeForm } from "@/components/TradeFormProvider";
import type { TradeMode } from "@/components/TradeForm";

export default function OpenTradeButton({
  kind,
  className,
  children,
}: {
  kind: TradeMode;
  className?: string;
  children: ReactNode;
}) {
  const { openForm } = useTradeForm();
  return (
    <button type="button" onClick={() => openForm(kind)} className={className}>
      {children}
    </button>
  );
}

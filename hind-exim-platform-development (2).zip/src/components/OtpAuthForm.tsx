"use client";

import Link from "next/link";
import { signIn } from "next-auth/react";
import { useEffect, useRef, useState } from "react";
import { AlertCircle, ArrowRight, Loader2, Phone, RotateCcw, ShieldCheck } from "lucide-react";

type Step = "phone" | "code" | "profile";

export default function OtpAuthForm({
  mode,
  callbackUrl,
}: {
  mode: "login" | "signup";
  callbackUrl: string;
}) {
  const [step, setStep] = useState<Step>("phone");
  const [phone, setPhone] = useState("");
  const [normalizedPhone, setNormalizedPhone] = useState("");
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [shownCode, setShownCode] = useState<string | null>(null);
  const [ticket, setTicket] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [seconds, setSeconds] = useState(0);
  const inputs = useRef<(HTMLInputElement | null)[]>([]);
  const isSignup = mode === "signup";

  useEffect(() => {
    if (seconds <= 0) return;
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [seconds]);

  async function sendCode(target?: string) {
    const number = (target ?? phone).trim();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const res = await fetch("/api/otp/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: number }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data?.error ?? "Could not send the code.");
        return;
      }
      const otp = String(data.code ?? "");
      const p = String(data.phone ?? number);
      setPhone(number);
      setNormalizedPhone(p);
      setShownCode(otp);
      setStep("code");
      const digits = otp.split("").slice(0, 6);
      setCode(digits);
      setSeconds(30);
      setNotice("Enter the 6-digit code shown below.");
      // Auto-verify so login does not get stuck
      if (otp.length === 6) {
        await runVerify(p, otp);
      }
    } finally {
      setBusy(false);
    }
  }

  async function runVerify(p: string, entered: string) {
    const res = await fetch("/api/otp/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone: p, code: entered }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(data?.error ?? "Verification failed.");
      return;
    }
    setTicket(data.ticket);
    if (data.needsProfile) {
      setStep("profile");
      setNotice("Phone verified. Set your name and password.");
      return;
    }
    await establishSession(data.ticket, data.phone ?? p);
  }

  function setDigit(i: number, value: string) {
    const digit = value.replace(/\D/g, "").slice(-1);
    setCode((prev) => {
      const next = [...prev];
      next[i] = digit;
      return next;
    });
    if (digit && i < 5) inputs.current[i + 1]?.focus();
  }

  async function verifyCode(e?: React.FormEvent) {
    e?.preventDefault();
    const entered = code.join("");
    if (entered.length !== 6) {
      setError("Enter all 6 digits.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await runVerify(normalizedPhone || phone, entered);
    } finally {
      setBusy(false);
    }
  }

  async function establishSession(t: string, p: string) {
    const res = await signIn("credentials", { phone: p, ticket: t, redirect: false });
    if (res?.error) {
      setError("Sign-in failed. Please try again.");
      return;
    }
    window.location.href = callbackUrl || "/dashboard";
  }

  async function completeProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!ticket) {
      setError("Session expired. Verify your phone again.");
      setStep("phone");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/otp/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: normalizedPhone || phone, name, password, ticket }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data?.error ?? "Could not save your profile.");
        return;
      }
      await establishSession(data.ticket, data.phone ?? normalizedPhone);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      {error && (
        <p className="mb-4 flex items-center gap-2 rounded-lg border border-red-500/40 bg-red-500/10 px-4 py-2.5 text-[13px] text-red-300">
          <AlertCircle size={14} /> {error}
        </p>
      )}
      {notice && !error && (
        <p className="mb-4 flex items-center gap-2 rounded-lg border border-leaf/40 bg-leaf/10 px-4 py-2.5 text-[13px] text-leaf">
          <ShieldCheck size={14} /> {notice}
        </p>
      )}

      {step === "phone" && (
        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            sendCode();
          }}
        >
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Phone number</label>
            <div className="relative">
              <Phone size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-dim" />
              <input
                type="tel"
                required
                autoFocus
                className="field pl-10"
                placeholder="98765 43210"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
          </div>
          <button
            type="submit"
            disabled={busy}
            className="clip-notch flex w-full items-center justify-center gap-2 bg-gold px-6 py-3.5 text-[14px] font-bold text-ink hover:bg-saffron disabled:opacity-60"
          >
            {busy ? <Loader2 size={15} className="animate-spin" /> : <Phone size={15} />}
            Get verification code
          </button>
        </form>
      )}

      {step === "code" && (
        <form className="space-y-4" onSubmit={verifyCode}>
          {shownCode && (
            <div className="rounded-xl border border-gold/50 bg-gold/10 px-4 py-4 text-center">
              <p className="stencil text-[9px] text-gold">Your verification code</p>
              <p className="mt-1 font-mono text-3xl font-black tracking-[0.35em] text-gold">{shownCode}</p>
            </div>
          )}
          <div className="flex gap-2">
            {code.map((digit, i) => (
              <input
                key={i}
                ref={(el) => {
                  inputs.current[i] = el;
                }}
                value={digit}
                onChange={(e) => setDigit(i, e.target.value)}
                inputMode="numeric"
                maxLength={1}
                className="field h-14 w-full p-0 text-center font-mono text-xl font-bold text-gold"
              />
            ))}
          </div>
          <button
            type="submit"
            disabled={busy}
            className="clip-notch flex w-full items-center justify-center gap-2 bg-gold px-6 py-3.5 text-[14px] font-bold text-ink hover:bg-saffron disabled:opacity-60"
          >
            {busy ? <Loader2 size={15} className="animate-spin" /> : <ShieldCheck size={15} />}
            Verify &amp; continue
          </button>
          <div className="flex justify-between text-[12px] text-mist">
            <button type="button" onClick={() => sendCode(phone)} disabled={busy || seconds > 0}>
              <RotateCcw size={12} className="mr-1 inline" />
              {seconds > 0 ? `Resend in ${seconds}s` : "Resend"}
            </button>
            <button type="button" onClick={() => setStep("phone")}>
              Change number
            </button>
          </div>
        </form>
      )}

      {step === "profile" && (
        <form className="space-y-4" onSubmit={completeProfile}>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Full name</label>
            <input required className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
          </div>
          <div>
            <label className="stencil mb-1.5 block text-[9px] text-dim">Password (6+ characters)</label>
            <input
              type="password"
              required
              minLength={6}
              className="field"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="clip-notch flex w-full items-center justify-center gap-2 bg-gold px-6 py-3.5 text-[14px] font-bold text-ink hover:bg-saffron disabled:opacity-60"
          >
            {busy ? <Loader2 size={15} className="animate-spin" /> : <ArrowRight size={15} />}
            {isSignup ? "Create account" : "Save & enter"}
          </button>
        </form>
      )}

      <p className="mt-6 text-center text-[13px] text-mist">
        {isSignup ? (
          <>
            Already have an account?{" "}
            <Link href="/login" className="font-semibold text-gold">
              Log in
            </Link>
          </>
        ) : (
          <>
            New here?{" "}
            <Link href="/signup" className="font-semibold text-gold">
              Create account
            </Link>
          </>
        )}
      </p>
    </div>
  );
}

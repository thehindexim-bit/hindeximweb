import { ArrowRight, Boxes, Hash, Phone, Scale, Ship } from "lucide-react";
import { SITE, timeAgo, type ClientRequirement } from "@/lib/site";

export default function ListingCard({ item }: { item: ClientRequirement }) {
  const isBuyer = item.kind === "buyer";
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-panel/70 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-gold/45 hover:shadow-[0_24px_60px_-30px_rgba(242,169,59,0.35)]">
      <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-gold/[0.06] blur-2xl transition-opacity duration-300 group-hover:opacity-100" />

      <div className="flex items-center justify-between gap-3">
        <span
          className={`stencil inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[9px] ${
            isBuyer ? "border-gold/50 bg-gold/10 text-gold" : "border-leaf/50 bg-leaf/10 text-leaf"
          }`}
        >
          {isBuyer ? <ArrowRight size={10} className="rotate-180" /> : <ArrowRight size={10} />}
          {isBuyer ? "Buy mandate" : "Supply offer"}
        </span>
        <span className="stencil text-[9px] text-dim">{timeAgo(item.createdAt)}</span>
      </div>

      <h3 className="font-display mt-4 text-lg font-bold leading-snug text-bone transition-colors group-hover:text-gold">
        {item.title}
      </h3>
      {item.description && (
        <p className="mt-2.5 line-clamp-3 text-[13px] leading-relaxed text-mist">{item.description}</p>
      )}

      <div className="mt-5 grid grid-cols-2 gap-2.5 text-[12px]">
        {item.hsCode && (
          <div className="flex items-center gap-2 rounded-lg border border-line2 bg-abyss/60 px-3 py-2 text-mist">
            <Hash size={12} className="shrink-0 text-gold/70" />
            <span className="truncate">HS {item.hsCode}</span>
          </div>
        )}
        {(item.quantity || item.unit) && (
          <div className="flex items-center gap-2 rounded-lg border border-line2 bg-abyss/60 px-3 py-2 text-mist">
            <Scale size={12} className="shrink-0 text-gold/70" />
            <span className="truncate">
              {item.quantity ?? "—"} {item.unit ?? ""}
            </span>
          </div>
        )}
        {(item.originCountry || item.destinationCountry) && (
          <div className="col-span-2 flex items-center gap-2 rounded-lg border border-line2 bg-abyss/60 px-3 py-2 text-mist">
            <Ship size={12} className="shrink-0 text-gold/70" />
            <span className="truncate">
              {item.originCountry ?? "Anywhere"}
              <ArrowRight size={10} className="mx-1.5 inline text-dim" />
              {item.destinationCountry ?? "Anywhere"}
            </span>
          </div>
        )}
        {item.priceRange && (
          <div className="col-span-2 flex items-center gap-2 rounded-lg border border-line2 bg-abyss/60 px-3 py-2 text-mist">
            <Boxes size={12} className="shrink-0 text-gold/70" />
            <span className="truncate">Terms: {item.priceRange}</span>
          </div>
        )}
      </div>

      <div className="mt-auto flex items-center justify-between gap-3 pt-6">
        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-bone">
            {item.company ?? item.contactName ?? item.postedByName ?? "Hind Exim desk"}
          </p>
          <p className="stencil mt-0.5 text-[8px] text-dim">
            {item.category} {item.contactName && item.company ? `· ${item.contactName}` : ""}
          </p>
        </div>
        <a
          href={SITE.phoneHref}
          className={`clip-notch flex shrink-0 items-center gap-2 px-4 py-2.5 text-[12px] font-semibold transition-colors ${
            isBuyer ? "bg-gold text-ink hover:bg-saffron" : "bg-leaf text-ink hover:brightness-110"
          }`}
        >
          <Phone size={12} />
          Discuss
        </a>
      </div>
    </article>
  );
}

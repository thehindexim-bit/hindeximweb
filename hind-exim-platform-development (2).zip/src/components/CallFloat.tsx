"use client";

import { MessageCircle, Phone } from "lucide-react";
import { SITE } from "@/lib/site";

export default function CallFloat() {
  return (
    <div className="fixed bottom-6 right-5 z-50 flex flex-col items-end gap-3 print:hidden">
      <a
        href={SITE.whatsapp}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="group flex h-12 w-12 items-center justify-center rounded-full border border-leaf/40 bg-panel/90 text-leaf shadow-[0_12px_40px_-12px_rgba(34,192,122,0.6)] backdrop-blur transition-all hover:scale-105 hover:bg-leaf hover:text-ink"
      >
        <MessageCircle size={19} />
      </a>
      <a
        href={SITE.phoneHref}
        aria-label={`Call ${SITE.phoneDisplay}`}
        className="group flex items-center gap-3 rounded-full border border-gold/50 bg-gold py-3 pl-4 pr-5 text-ink shadow-[0_12px_40px_-12px_rgba(242,169,59,0.75)] transition-all hover:scale-[1.03] hover:bg-saffron"
      >
        <span className="relative flex h-7 w-7 items-center justify-center">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-ink/25" />
          <Phone size={15} className="relative" />
        </span>
        <span className="text-[13px] font-bold tracking-wide">{SITE.phoneDisplay}</span>
      </a>
    </div>
  );
}

"use client";

import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import TradeForm, { type TradeMode } from "@/components/TradeForm";

type TradeFormContextValue = {
  openForm: (mode: TradeMode) => void;
};

const TradeFormContext = createContext<TradeFormContextValue>({
  openForm: () => {},
});

export function useTradeForm() {
  return useContext(TradeFormContext);
}

export function TradeFormProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<{ open: boolean; mode: TradeMode }>({
    open: false,
    mode: "buyer",
  });

  const openForm = useCallback((mode: TradeMode) => {
    setState({ open: true, mode });
  }, []);

  return (
    <TradeFormContext.Provider value={{ openForm }}>
      {children}
      <div className="fixed bottom-6 left-5 z-[70] flex flex-col gap-3 print:hidden">
        <button
          onClick={() => openForm("seller")}
          className="clip-notch flex items-center gap-2 bg-leaf px-4 py-3 text-[12px] font-bold text-ink shadow-[0_12px_40px_-12px_rgba(34,192,122,0.75)] transition-transform hover:scale-[1.03]"
        >
          <ArrowUpRight size={14} />
          I want to sell
        </button>
        <button
          onClick={() => openForm("buyer")}
          className="clip-notch flex items-center gap-2 bg-gold px-4 py-3 text-[12px] font-bold text-ink shadow-[0_12px_40px_-12px_rgba(242,169,59,0.75)] transition-transform hover:scale-[1.03]"
        >
          <ArrowDownRight size={14} />
          I want to buy
        </button>
      </div>
      {state.open && (
        <TradeForm initialMode={state.mode} onClose={() => setState((s) => ({ ...s, open: false }))} />
      )}
    </TradeFormContext.Provider>
  );
}

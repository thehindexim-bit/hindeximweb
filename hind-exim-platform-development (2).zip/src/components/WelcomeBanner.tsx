"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { CheckCircle2 } from "lucide-react";

export default function WelcomeBanner() {
  const params = useSearchParams();
  const [show, setShow] = useState(false);
  const [kind, setKind] = useState<"in" | "up">("in");

  useEffect(() => {
    const w = params.get("welcome");
    if (w === "1" || w === "signup") {
      setKind(w === "signup" ? "up" : "in");
      setShow(true);
      const t = setTimeout(() => setShow(false), 4500);
      window.history.replaceState({}, "", "/");
      return () => clearTimeout(t);
    }
  }, [params]);

  if (!show) return null;

  return (
    <div className="fixed inset-x-0 top-[76px] z-[80] flex justify-center px-4">
      <div className="flex items-center gap-3 rounded-2xl border border-leaf/40 bg-panel/95 px-5 py-3.5 text-[14px] font-semibold text-leaf shadow-[0_20px_50px_-20px_rgba(34,192,122,0.6)] backdrop-blur">
        <CheckCircle2 size={18} />
        {kind === "up" ? "Account created. You are logged in." : "Successfully logged in."}
      </div>
    </div>
  );
}

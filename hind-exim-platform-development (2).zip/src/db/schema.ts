import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  username: text("username").unique(),
  email: text("email").unique(),
  phone: text("phone").unique(),
  passwordHash: text("password_hash"),
  role: text("role").notNull().default("user"),
  provider: text("provider").notNull().default("credentials"),
  image: text("image"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
});

export const requirements = pgTable("requirements", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull(), // "buyer" | "seller"
  title: text("title").notNull(),
  category: text("category").notNull().default("General"),
  hsCode: text("hs_code"),
  quantity: text("quantity"),
  unit: text("unit"),
  originCountry: text("origin_country"),
  destinationCountry: text("destination_country"),
  priceRange: text("price_range"),
  description: text("description"),
  company: text("company"),
  contactName: text("contact_name"),
  postedByName: text("posted_by_name"),
  postedByEmail: text("posted_by_email"),
  postedByPhone: text("posted_by_phone"),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  status: text("status").notNull().default("open"), // "open" | "closed"
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const otpOutbox = pgTable("otp_outbox", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull(),
  code: text("code").notNull(),
  waUrl: text("wa_url"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const phoneOtps = pgTable("phone_otps", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull(),
  codeHash: text("code_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  attempts: integer("attempts").notNull().default(0),
  consumedAt: timestamp("consumed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const phoneAuthTickets = pgTable("phone_auth_tickets", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  phone: text("phone").notNull(),
  purpose: text("purpose").notNull().default("login"),
  usedAt: timestamp("used_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const loginEvents = pgTable("login_events", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  provider: text("provider").notNull().default("email"),
  userId: integer("user_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const supplierRequests = pgTable("supplier_requests", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull(),
  contactName: text("contact_name").notNull(),
  email: text("email"),
  phone: text("phone").notNull(),
  sector: text("sector").notNull(),
  commodity: text("commodity").notNull(),
  originCountry: text("origin_country").notNull(),
  gstNumber: text("gst_number"),
  panNumber: text("pan_number"),
  companyAddress: text("company_address"),
  city: text("city"),
  state: text("state"),
  description: text("description"),
  status: text("status").notNull().default("pending"), // "pending" | "approved" | "rejected"
  reviewedBy: integer("reviewed_by").references(() => users.id, { onDelete: "set null" }),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type UserRow = typeof users.$inferSelect;
export type RequirementRow = typeof requirements.$inferSelect;
export type LoginEventRow = typeof loginEvents.$inferSelect;
export type SupplierRequestRow = typeof supplierRequests.$inferSelect;

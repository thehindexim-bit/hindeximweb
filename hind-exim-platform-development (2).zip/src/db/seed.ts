import "dotenv/config";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db, pool } from "./index";
import { requirements, users } from "./schema";

const ADMIN_EMAIL = "admin@hindexim.com";
const ADMIN_PASSWORD = "HindExim@2026";

async function main() {
  console.log("Seeding Hind Exim database…");

  const [existingAdmin] = await db.select().from(users).where(eq(users.email, ADMIN_EMAIL)).limit(1);
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    await db.insert(users).values({
      name: "Hind Exim Admin",
      email: ADMIN_EMAIL,
      passwordHash,
      role: "admin",
      provider: "credentials",
    });
    console.log(`Admin created → ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`);
  } else {
    console.log("Admin already exists, skipping.");
  }

  const seeded = [
    {
      kind: "buyer",
      title: "Basmati Rice — 1121 Steam, A-Grade",
      category: "Agriculture & Food",
      hsCode: "1006.30",
      quantity: "500",
      unit: "MT",
      originCountry: "India",
      destinationCountry: "UAE",
      priceRange: "FOB Mundra · $880–940/MT · LC at sight",
      description:
        "Gulf import house requires monthly 500 MT 1121 steam basmati, 25kg PP bags, SGS inspection at loading. Trial shipment of 2×40FT before annual contract.",
      company: "Al Noor Foodstuff Trading LLC",
      contactName: "Mr. Rashid",
    },
    {
      kind: "buyer",
      title: "Turmeric Fingers — Erode Quality, 5% Curcumin",
      category: "Spices",
      hsCode: "0910.30",
      quantity: "50",
      unit: "MT",
      originCountry: "India",
      destinationCountry: "Netherlands",
      priceRange: "CIF Rotterdam · target $1,420/MT",
      description:
        "EU spice distributor seeking polished turmeric fingers, pesticide-tested per EU MRL norms, steam sterilization preferred. Quarterly volumes.",
      company: "Van Der Meer Spices BV",
      contactName: "Ms. Janssen",
    },
    {
      kind: "buyer",
      title: "Combed Cotton Yarn — 40s, Knitting Grade",
      category: "Textiles & Apparel",
      hsCode: "5205.24",
      quantity: "20",
      unit: "MT",
      originCountry: "India",
      destinationCountry: "Egypt",
      priceRange: "CFR Alexandria · open to discuss",
      description:
        "Egyptian fabric mill buying carded/combed yarn on rolling basis. Require cone packing, contamination-free, with cotton certificates.",
      company: "Nile Textile Industries",
      contactName: "Mr. Hassan",
    },
    {
      kind: "buyer",
      title: "Paracetamol API — IP/BP Grade",
      category: "Pharmaceuticals",
      hsCode: "2924.29",
      quantity: "5",
      unit: "MT",
      originCountry: "India",
      destinationCountry: "Brazil",
      priceRange: "CPT Santos · registered suppliers only",
      description:
        "Pharma importer with ANVISA dossier requirements. Need GMP-certified manufacturer with COA, DMF support and stability data.",
      company: "Sul Farma Importadora",
      contactName: "Dr. Souza",
    },
    {
      kind: "seller",
      title: "Alphonso Mangoes — GI-Tagged Ratnagiri",
      category: "Agriculture & Food",
      hsCode: "0804.50",
      quantity: "10",
      unit: "MT",
      originCountry: "India",
      destinationCountry: "United Kingdom",
      priceRange: "Air freight · $4.10–4.60/kg CIF",
      description:
        "Seasonal supply from GI-tagged orchards, hot-water treated per EU norms, 3kg and 6kg retail boxes. Weekly air consignments April–June.",
      company: "Konkan Agro Exports",
      contactName: "Mr. Deshmukh",
    },
    {
      kind: "seller",
      title: "Copper Wire Scrap — Millberry 99.9%",
      category: "Metals & Scrap",
      hsCode: "7404.00",
      quantity: "200",
      unit: "MT",
      originCountry: "India",
      destinationCountry: "Anywhere",
      priceRange: "LME-linked · FOB Nhava Sheva",
      description:
        "Monthly 200 MT millberry copper scrap with loading photos, video and third-party assay. Trial 1×20FT accepted for new buyers.",
      company: "Vedha Metals Recycling",
      contactName: "Mr. Iyer",
    },
    {
      kind: "seller",
      title: "Handloom Cotton Bedsheet Sets — 120TC",
      category: "Textiles & Apparel",
      hsCode: "6304.11",
      quantity: "50000",
      unit: "PCS",
      originCountry: "India",
      destinationCountry: "USA",
      priceRange: "FOB Tuticorin · from $3.85/set",
      description:
        "OEKO-TEX certified handloom cluster supplying private-label home textiles. Custom prints, GSM and sizes on 30-day lead time.",
      company: "Karur Handloom Collective",
      contactName: "Ms. Lakshmi",
    },
    {
      kind: "seller",
      title: "Green Cardamom — 8mm, Bold, Export Grade",
      category: "Spices",
      hsCode: "0908.31",
      quantity: "2",
      unit: "MT",
      originCountry: "India",
      destinationCountry: "Saudi Arabia",
      priceRange: "CIF Jeddah · $28–32/kg",
      description:
        "Idukki-origin bold green cardamom, machine-dried, vacuum packed in 25kg cartons. Ready stock with phytosanitary certification.",
      company: "High Range Spice Co.",
      contactName: "Mr. Thomas",
    },
  ] as const;

  const existing = await db.select({ id: requirements.id }).from(requirements).limit(1);
  if (existing.length === 0) {
    await db.insert(requirements).values(
      seeded.map((s) => ({
        ...s,
        postedByName: "Hind Exim Desk",
        postedByEmail: ADMIN_EMAIL,
        userId: null,
        status: "open",
      }))
    );
    console.log(`Seeded ${seeded.length} trade listings.`);
  } else {
    console.log("Listings already exist, skipping.");
  }

  await pool.end();
  console.log("Done.");
}

main().catch(async (e) => {
  console.error(e);
  try {
    await pool.end();
  } catch {}
  process.exit(1);
});
